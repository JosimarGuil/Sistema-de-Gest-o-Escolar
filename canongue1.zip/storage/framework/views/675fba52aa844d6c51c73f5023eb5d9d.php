<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>miuda seria pah, a unica fiel que restou no MUNDOOOOOOO</h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\teste\resources\views/joia.blade.php ENDPATH**/ ?>