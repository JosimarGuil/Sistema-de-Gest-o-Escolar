
<?php $__env->startSection('title','listar'); ?>


<?php $__env->startSection('content'); ?>
    <h1>listar users </h1>
    <a href="/add"> adicionar usuarios</a><br>
    
    <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($item->name); ?>  <?php echo e($item->email); ?> 
            <a href="/pagar/<?php echo e($item->id); ?>">editar</a>
              <a href="">deletar</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste\resources\views/users/listar.blade.php ENDPATH**/ ?>