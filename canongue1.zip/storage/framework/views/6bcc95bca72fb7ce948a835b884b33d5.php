
<?php $__env->startSection('title','Adicionar Users'); ?>

<?php $__env->startSection('content'); ?>
<h2>Adicionar usuarios</h2>
<a href="\listarr">listar users</a>
<hr>

<?php if(session('sms')): ?>
 <p style="color:green"><?php echo e(session('sms')); ?></p>
<?php endif; ?>

<form action="/add" method="post">
    <?php echo csrf_field(); ?>
    <label for="">Name</label><br>
    <input type="text" name="name"><br><br>
    <label for="">email</label><br>
    <input type="email" name="email"><br><br>
    <label for="">Password</label><br>
    <input type="passord" name="password"><br><br>
 <button type="submit">Enviar</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste\resources\views/users/adi.blade.php ENDPATH**/ ?>