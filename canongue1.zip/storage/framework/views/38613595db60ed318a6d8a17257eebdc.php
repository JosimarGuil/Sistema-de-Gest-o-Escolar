

<?php $__env->startSection('title', 'Gestão de Usuários'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Painel de Getão de Usuários</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Painel</a></li>
                            <li class="breadcrumb-item active">Usuários</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Mensagens de retorno -->
        <section class="content-header">
            <div class="container-fluid">
                <?php if(session('sms1')): ?>
                    <div class="" style=" margin-bottom: 10px;">
                        <div class="card">
                            <div class="bg-primary" style="width:100%; margin: auto;
 padding: 10px; ">
                                <span><?php echo e(session('sms1')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms2')): ?>
                    <div class=" " style=" margin-bottom: 10px; ">
                        <div class="card">
                            <div class="bg-danger" style="width:100%; margin: auto;
padding: 10px; ">
                                <span><?php echo e(session('sms2')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms3')): ?>
                    <div class=" " style=" margin-bottom: 10px; border-radius: 5px ">
                        <div class="card">
                            <div class="bg-success" style="width:100%; margin: auto;
           padding: 10px; ">
                                <span><?php echo e(session('sms3')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('warning')): ?>
                    <div class="" style=" margin-bottom: 10px;">
                        <div class="bg-danger" style="width:100%; margin: auto;
padding: 10px; border-radius: 15px">
                            <span><?php echo e(session('warning')); ?></span>
                            <div class="card-tools" style="float: right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="container-fluid">

                <div class="card card-warning card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-edit"></i>
                            Painel de Gestão de usuários
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="col-12">

                            <button type="button" class="btn btn-primary toastrDefaultWarning " data-toggle="modal"
                                data-target="#modal-defaultciclus1" onclick="Verlunos()" style="display: none"
                                id="bver">
                                Listar todos usuários cadastrados no sistema
                            </button>

                        </div>

                       <span>Zona restrita ao SEO da escola</span>
                    </div>
                    <!-- /.card -->
                </div>
            </div>

            <!--TABELA DE LISTAGEM DOS USUÁRIOS-->

            <div class="container-fluid" id="listalunos">
                <div class="row">
                    <div class="col-12">


                        <div class="card">
                            <div class="card-header">

                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            
                                            <th>Nome Completo</th>
                                            <th>Telefone</th>
                                            <th>Cargo</th>   
                                            <th>Sexo</th>     
                                            <th>Nascimento</th>
                                            <th>Status</th>
                                            <th>ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->fone); ?></td>
                                                <td><?php echo e($item->perfil); ?></td>
                                                <td><?php echo e($item->sexo); ?></td>
                                                <td><?php echo e($item->data); ?></td>
                                                <td>
                                                    <?php if($item->status==true): ?>
                                                        <?php echo e('Activo'); ?>

                                                        <?php else: ?>
                                                        <?php echo e('Inativo'); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                            <button class="btn btn-primary" data-toggle="modal"
                                                            data-target="#modal-lgDetalhes<?php echo e($item->id); ?>"><i
                                                            class="fas fa-eye"></i> </button>
                                                           
                                                           
                                                            
                                                            <button class="btn btn-success" data-toggle="modal"
                                                            data-target="#modal-xl<?php echo e($item->id); ?>"><i
                                                                class="fas fa-edit"></i></button>
                                                                
                                                    <button class="btn btn-danger" data-toggle="modal"
                                                    data-target="#modal-defaultedialuno<?php echo e($item->id); ?>"><i
                                                    class="fas fa-trash"></i></button>

                                                    <?php if($item->status==true): ?>
                                                    <form action="<?php echo e(route('desbilitar',$item->id)); ?>" method="post" style="display: inline-block">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <input type="hidden" name="status" value="0">
                                                        <button class="btn btn-danger" data-toggle="modal"
                                                        type="submit"
                                                        data-target="#edit<?php echo e($item->id); ?>">Desativar</button>

                                                    </form>
                                                    <?php else: ?>
                                                    <form action="<?php echo e(route('desbilitar',$item->id)); ?>" method="post" style="display: inline-block">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <input type="hidden" name="status" value="1">
                                                        <button class="btn btn-info" data-toggle="modal"
                                                        type="submit"
                                                        data-target="#edit<?php echo e($item->id); ?>">Ativar</button>

                                                    </form>
                                                <?php endif; ?>
                                                    
                                                </td>
                                            </tr>
                                            <!-- MODAL VER DETALHES DO ALUNO -->

                                            <div class="modal fade" id="modal-lgDetalhes<?php echo e($item->id); ?>">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Detalhes do Usuário</h4>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <!-- Main content -->

                                                            <div class="card">
         
                                                                <div class="card-body">
                                                                  <div class="row">
                                                                    <div class="col-12 col-md-12">
                                                                      <div class="row">
                                                                        <div class="col-12">
                                                                            <div class="post">
                                                                              <div class="user-block">
                                                                                <img class="img-circle img-bordered-sm" src="../storage/<?php echo e($item->foto??''); ?>"
                                                                                 target="_blank" alt="user image" style="width: 150px; height: 150px; border-color:rgb(0, 174, 255);
                                                                                 border-radius: 5px">   
                                                                              </div>
                                                                              <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <p>     
                                                                                        <h3 class="profile-username text-info"><?php echo e($item->name??''); ?></h3>  
                                                                                    </p>
                                                                                    <p><i class="fas fa-user text-info"> Genero: </i> <?php echo e($item->sexo??''); ?></p>   
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <br>
                                                                                    <p><i class="fas fa-envelope text-info"> Email: </i> <?php echo e($item->email??''); ?></p>
                                                                                    <p><i class="fas fa-map-marker-alt mr-1 text-info"> Morada: </i> <?php echo e($item->morada??''); ?></p>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <p><i class="fas fa-phone text-info"> Telefone: </i> <?php echo e($item->fone??''); ?></p>
                                                                                    <?php if($item->whatsapp): ?>
                                                                                    <p><i class="nav-icon far fa-circle text-info"> Whatsapp: </i> <?php echo e($item->whatsapp??''); ?></p>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <p><i class="nav-icon far fa-circle text-info"> Cargo: </i> <?php echo e($item->perfil??''); ?></p>
                                                                                    <p><i class="nav-icon far fa-circle text-info "> Status: </i> <?php echo e($item->status==1?'Ativo': 'Inativo'); ?></p>   
                                                                                </div><br><br>
                                                                                <div class="col-md-12">
                                                                                    <br>
                                                                                    <a href="../storage/<?php echo e($item->documentos??''); ?>" 
                                                                                        target="_blank"
                                                                                        class="btn btn-info">  Ver documentação completa do Funcionário</a>
                                                                                  
                                                                                </div>
                                                                              </div>                                                                            
                                                                        </div>

                                                                      </div>
                                                                     </div>
                                                                     
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
    

                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">fechar</button>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>
                                            <!-- /.modal -->
                                            <!--MODAL DE DELETAÇÃO DE USUÁRIOS-->
                                            <div class="modal fade" id="modal-defaultedialuno<?php echo e($item->id); ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">AVISO !</h4>

                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <span class="text-danger">Tem certeza que deseja
                                                                Excluir<strong> <?php echo e($item->name); ?></strong> ?</span>
                                                            <form action="<?php echo e(route('Deleteusuario', $item->id)); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>

                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="submit" class="btn btn-danger">Sim</button>
                                                            </form>
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">Não</button>

                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>
                                            <!--ZONA DE EDICAO DE USUARIO--->
                                            <div class="modal fade" id="modal-xl<?php echo e($item->id); ?>">
                                                <div class="modal-dialog modal-xl">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h6 class="modal-title text-primary">Editando Usuário:
                                                                <?php echo e($item->name); ?></h6>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                            <form id="quickForm" method="post"
                                                                action="<?php echo e(route('Editusuario', $item->id)); ?>"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="card-body">
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Nome
                                                                            Completo*</label>
                                                                        <input type="text" maxlength="50"
                                                                            min="5" name="nome"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            required placeholder="Nome Completo"
                                                                            value="<?php echo e(old('nome', $item->name)); ?>">
                                                                        <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="">Sexo*</label><br>
                                                                        <label for="exampleInputEmail1">Masculino</label>
                                                                        <input type="radio" name="sexo"
                                                                            id="" value="Masculino"
                                                                            <?php echo e($item->sexo == 'Masculino' ? 'checked' : ''); ?>>
                                                                        <label for="exampleInputEmail1">Femenino</label>
                                                                        <input type="radio" name="sexo"
                                                                            id="" value=" Femenino"
                                                                            <?php echo e($item->sexo == 'Femenino' ? 'checked' : ''); ?>>
                                                                        <br> <span>Selecione o sexo do usuário</span>
                                                                        <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Data de
                                                                            Nascimento*</label>
                                                                        <input type="date" name="data" required
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            value="<?php echo e(old('data', $item->data)); ?>"
                                                                            placeholder="Data de Nascimento">
                                                                        <?php $__errorArgs = ['data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label
                                                                            for="exampleInputPassword1">Localidade*</label>
                                                                        <input type="map" name="localiza" required
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            placeholder="Localidade" minlength="15"
                                                                            maxlength="35"
                                                                            value="<?php echo e(old('localiza', $item->morada)); ?>">
                                                                        <?php $__errorArgs = ['localiza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Email</label>
                                                                        <input type="email" maxlength="50"
                                                                            minlength="5" name="email"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            value="<?php echo e(old('email', $item->email)); ?>"
                                                                            placeholder="E-mail">
                                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label
                                                                            for="exampleInputPassword1">Telefone*</label>
                                                                        <input type="tel" name="fone" required
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            value="<?php echo e(old('fone',$item->fone)); ?>"
                                                                            placeholder="Telefone" min="9"
                                                                            max="9">
                                                                        <?php $__errorArgs = ['fone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Número do Whatsapp</label>
                                                                        <input type="tel" name="What"
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            value="<?php echo e(old('What', $item->whatsapp)); ?>"
                                                                            placeholder="What" min="9"
                                                                            max="9">
                                                                        <?php $__errorArgs = ['What'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Cargo*</label>
                                                                        <select name="perfil" id="" required class="form-control">
                                                                            <option value="">Selecior um Cargo</option>
                                                                            <option value="SEO"
                                                                            <?php echo e($item->perfil=='SEO'?'selected':''); ?>>SEO</option>
                                                                            <option value="Professor"
                                                                            <?php echo e($item->perfil=='Professor'?'selected':''); ?>>Professor</option>
                                                                            <option value="Dir Geral"
                                                                            <?php echo e($item->perfil=='Dir Geral'?'selected':''); ?>>Dir Geral</option>
                                                                            <option value="Dir Administrativo" 
                                                                            <?php echo e($item->perfil=='Dir Administrativo'?'selected':''); ?>>Dir Administrativo</option> 
                                                                            <option value="Secretário Geral"
                                                                            <?php echo e($item->perfil=='Secretário Geral'?'selected':''); ?>>Secretário Geral</option>
                                                                            <option value="Secretário Pedagógico"
                                                                            <?php echo e($item->perfil=='Secretário Pedagógico'?'selected':''); ?>>Secretário Pedagógico</option>
                                                                            <option value="Secretário Financeiro"
                                                                            <?php echo e($item->perfil=='Secretário Financeiro'?'selected':''); ?>>Secretário Financeiro</option>
                                                                            <option value="Financeiro"
                                                                            <?php echo e($item->perfil=='Financeiro'?'selected':''); ?>>Financeiro</option>
                                                                            <option value="Dr Pedagógico"
                                                                            <?php echo e($item->perfil=='Dr Pedagógico'?'selected':''); ?>>Dr Pedagógico</option>
                                                                            <option value="Seguraça"
                                                                            <?php echo e($item->perfil=='Dr Pedagógico'?'selected':''); ?>>Segurança</option>
                                                                            <option value="Dir Geral"
                                                                            <?php echo e($item->perfil=='Dir Geral'?'selected':''); ?>>Dir Geral</option>
                                                                            <option value="Higiene/Limpeza"
                                                                            <?php echo e($item->perfil=='Higiene/Limpeza'?'selected':''); ?>>Higiene/Limpeza</option>
                                                                            <option value="Vigilante"
                                                                            <?php echo e($item->perfil=='Vigilante'?'selected':''); ?>>Vigilante</option>
                                                                            <?php $__errorArgs = ['perfil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </select>
                                                                    </div>
                            

                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Senha*</label>
                                                                        <input name="password" type="password"
                                                                            value="<?php echo e(old('password')); ?>"
                                                                             class="form-control" maxlength="15" min="8">
                                                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Foto Meio
                                                                            Corpo*</label>
                                                                        <input type="file" maxlength="50"
                                                                            min="5" name="foto"
                                                                            value="<?php echo e($item->foto); ?>"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            placeholder="Nome Completo">
                                                                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Documentação
                                                                            Completa*</label>
                                                                        <input type="file" maxlength="50"
                                                                            min="5" name="doc"
                                                                            value="<?php echo e($item->documentos); ?>"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            placeholder="Nome Completo">
                                                                        <?php $__errorArgs = ['doc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="submit" class="btn btn-success">Editar</button>
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">Fechar</button>
                                                          
                                                            </form>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-danger">Nenhum funciorario foi cadastrado!</span>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttt\resources\views/painel/user.blade.php ENDPATH**/ ?>