

<?php $__env->startSection('title', 'Controle de Pagamentos'); ?>



<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>
                            Gerenciamento de Contas
                        </h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Painel</a></li>
                            <li class="breadcrumb-item active">Gerenciamento de Contas</li>
                        </ol>
                    </div>
                </div>

            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?php echo e($totalEntradas); ?> <sup style="font-size: 25px; "><small
                                            class="text-warning">Kz</small></sup></h3>

                                <p>Entradas</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>

                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3>444 <sup style="font-size: 25px; "><small class="text-warning">Kz</small></sup></h3>

                                <p>Saídas</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-stats-bars"></i>
                            </div>

                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-4 col-6">
                        <!-- small box -->
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3 class="text-white"><?php echo e($total); ?> <sup style="font-size: 25px; "><small
                                            class="text-warning">Kz</small></sup></h3>

                                <p class="text-white">Total</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-person-add"></i>
                            </div>

                        </div>
                    </div>
                    <!-- ./col -->

                </div>
                <!-- /.row -->

            </div>
        </section>

         <!-- Mensagens de retorno -->
         <section class="content-header">
            <div class="container-fluid">
                <?php if(session('sms1')): ?>
                    <div class="" style=" margin-bottom: 10px;">
                        <div class="card">
                            <div class="bg-primary" style="width:100%; margin: auto;
 padding: 10px; ">
                                <span><?php echo e(session('sms1')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms2')): ?>
                    <div class=" " style=" margin-bottom: 10px; ">
                        <div class="card">
                            <div class="bg-danger" style="width:100%; margin: auto;
padding: 10px; ">
                                <span><?php echo e(session('sms2')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms3')): ?>
                    <div class=" " style=" margin-bottom: 10px; border-radius: 5px ">
                        <div class="card">
                            <div class="bg-success" style="width:100%; margin: auto;
           padding: 10px; ">
                                <span><?php echo e(session('sms3')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('warning')): ?>
                    <div class="" style=" margin-bottom: 10px;">
                        <div class="bg-danger" style="width:100%; margin: auto;
padding: 10px; border-radius: 15px">
                            <span><?php echo e(session('warning')); ?></span>
                            <div class="card-tools" style="float: right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content" style="margin-top: 20px">
            <div class="container-fluid">
                <div class="card card-warning card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-edit"></i>
                            Painel de Configuração
                        </h3>
                    </div>
                    <div class="card-body  justify-content-around">

                        <button type="button" class="btn btn-success toastrDefaultSuccess " data-toggle="modal"
                            data-target="#modal-defaultciclus1">
                            Adicionar Tipos de pagamento
                        </button>

                        <button type="button" class="btn btn-info  toastrDefaultInfo" data-toggle="modal"
                            data-target="#modal-defaultcursos2">
                            Adicionar Entrada
                        </button>

                        <button type="button" class="btn btn-primary  toastrDefaultInfo" data-toggle="modal"
                            data-target="#modal-defaultcursos2">
                            Adicionar Saídas
                        </button>


                        <div class="text-muted mt-3">
                            Somente o Director geral tem esse Acesso
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.col -->



            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Tipos de Busca</h3><br>
                        <hr>


                        <button id="btipo" type="button" class="btn btn-default toastrDefaultError"
                            onclick="verTposPagamentos(this)" style="color: white;background-color:#007bff ">
                            Ver toda Tipos de Pagamentos
                        </button>

                        <button id="bne" type="button" class="btn btn-default toastrDefaultError"
                            onclick="verEntradas(this)">
                            Ver todas entradas
                        </button>
                        <button id="bsaida" type="button" class="btn btn-default toastrDefaultError"
                            onclick=" classes(this)">
                            Ver tipos de pagamentos
                        </button>

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <!--TABELA DOS TIPOS-->
                        <div id="tipo" style="display: block">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Tipo</th>
                                        <th>Classe</th>
                                        <th>Preço</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($tipo->tipo); ?></td>
                                            <td><?php echo e(isset($tipo->clace->curso_id) ? $tipo->clace->nome . '-' . $tipo->clace->curso->nome : $tipo->clace->nome); ?>

                                            </td>
                                            <td><?php echo e($tipo->preco); ?></td>
                                            <td>----</td>
                                            <td>----</td>
                                            <td>

                                                <button class="btn btn-success" data-toggle="modal"
                                                    data-target="#modal-defaultedittipo<?php echo e($tipo->id); ?>"><i
                                                        class="fas fa-edit"></i></button>


                                                <button class="btn btn-danger" data-toggle="modal"
                                                    data-target="#modal-defaultdeletetipo<?php echo e($tipo->id); ?>"
                                                    style="display: inline-block"><i class="fas fa-trash"></i></button>

                                            </td>

                                        </tr>
                                        <div class="modal fade" id="modal-defaultdeletetipo<?php echo e($tipo->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">AVISO!</h4>

                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <span class="text-danger">Tem certeza que deseja Excluir este
                                                            tipo de pagamento
                                                            <strong> </strong> ?</span>
                                                        <form action="<?php echo e(route('deleteTipoPagamentos', $tipo->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>

                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="submit" class="btn btn-danger">Sim</button>
                                                        </form>
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Não</button>

                                                    </div>
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                        <div class="modal fade" id="modal-defaultedittipo<?php echo e($tipo->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Editar Tipo de Pagamento</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form id="quickForm"
                                                            action="<?php echo e(route('editTipoPagamentos', $tipo->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <div class="card-body">
                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Tipo de
                                                                        pagamento</label>
                                                                    <input type="text" name="tipo"
                                                                        class="form-control" required
                                                                        value="<?php echo e(old('tipo', $tipo->tipo)); ?>">
                                                                    <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Preço</label>
                                                                    <input type="number" name="preco"
                                                                        class="form-control" required
                                                                        value="<?php echo e(old('preco', $tipo->preco)); ?>">
                                                                    <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Classe</label>
                                                                    <select name="clace_id" id=""
                                                                        class="form-control" required>
                                                                        <option value="">Selecionar classe</option>
                                                                        <?php $__empty_2 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                            <?php if(isset($siculo->curso_id)): ?>
                                                                                <option value="<?php echo e($siculo->id); ?>"
                                                                                    <?php echo e($siculo->nome == $tipo->clace->nome ? 'selected' : ''); ?>>
                                                                                    <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?>

                                                                                </option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($siculo->id); ?>"
                                                                                    <?php echo e($siculo->nome == $tipo->clace->nome ? 'selected' : ''); ?>>
                                                                                    <?php echo e($siculo->nome . '-' . $siculo->siculo->nome); ?>

                                                                                </option>
                                                                            <?php endif; ?>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                        <?php endif; ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['clace_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>

                                                            </div>
                                                            <!-- /.card-body -->
                                                            <div class="card-footer">

                                                            </div>

                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="submit" class="btn btn-success">Editar</button>
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Fechar</button>

                                                        </form>
                                                    </div>

                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="text-danger">Nehum foi encontrado</span>
                                    <?php endif; ?>
                                <tfoot>
                                    <tr>
                                        <th>Codigo</th>
                                        <th>Cíclo</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>Ações</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <!--TABELA DAS ENTRADAS DE PAGAMENTO-->
                        <div id="entradas" style="display: none">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Aluno</th>
                                        <th>Tipo</th>
                                        <th>Total</th>
                                        <th>Data e Hora</th>

                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $pamentosEntradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($item->aluno->nome); ?></td>
                                           
                                            <td><?php echo e($item->tipo_pagamento->tipo); ?></td>
                                             <td><?php echo e($item->total); ?> Kz</td>
                                            <td><?php echo e($item->created_at); ?></td>
                                           
                                            <td>
                                                <button class="btn btn-primary" data-toggle="modal"
                                                    data-target="#modal-lgDetalhes<?php echo e($item->id); ?>"><i
                                                        class="fas fa-eye"></i></button>

                                                <button class="btn btn-success" data-toggle="modal"
                                                    data-target="#modal-xl<?php echo e($item->id); ?>"><i
                                                        class="fas fa-edit"></i></button>


                                                <button class="btn btn-danger" data-toggle="modal"
                                                    data-target="#modal-defaultedialuno<?php echo e($item->id); ?>"
                                                    style="display: inline-block"><i class="fas fa-trash"></i></button>

                                            </td>
                                            </td>
                                        </tr>
                                        </tr>
                                        <!-- MODAL VER DETALHES DO ALUNO -->

                                        <div class="modal fade" id="modal-lgDetalhes<?php echo e($item->id); ?>">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Detalhes do aluno</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">

                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="col-12 col-md-12">
                                                                    <div class="row">
                                                                        <div class="col-12">
                                                                            <div class="post">
                                                                                <div class="user-block">
                                                                                    <a
                                                                                        href="../storage/<?php echo e($item->img ?? ''); ?>">
                                                                                        <img class="img-circle img-bordered-sm"
                                                                                            target="_blank"
                                                                                            src="../storage/<?php echo e($item->img ?? ''); ?>"
                                                                                            alt="user image"
                                                                                            style="width: 100px; height: 80px;">
                                                                                    </a>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <p>
                                                                                        <h3
                                                                                            class="profile-username text-primary ">
                                                                                            <?php echo e($item->nome ?? ''); ?></h3>
                                                                                        </p>
                                                                                        <p><i class="fas fa-user ">
                                                                                                Gênero:</i>
                                                                                            <?php echo e($item->sexo ?? ''); ?></p>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <br>
                                                                                        <p><i class="fas fa-envelope ">
                                                                                                E-mail:</i>
                                                                                            <?php echo e($item->email ?? ''); ?></p>
                                                                                        <p><i
                                                                                                class="fas fa-map-marker-alt mr-1 ">Morada:</i>
                                                                                            <?php echo e($item->localiza ?? ''); ?></p>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <p><i class="fas fa-phone ">
                                                                                                Telefone:</i>
                                                                                            <?php echo e($item->fone ?? ''); ?></p>
                                                                                        <?php if($item->whatsapp): ?>
                                                                                            <p><i class="fas fa-phone ">
                                                                                                    Whatsapp:</i>
                                                                                                <?php echo e($item->whatsapp ?? ''); ?>

                                                                                            </p>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <p><i
                                                                                                class="nav-icon far fa-circle">Curso/Cíclo:</i>
                                                                                          
                                                                                        </p>
                                                                                        <p><i
                                                                                                class="nav-icon far fa-circle">Sexo:</i>
                                                                                            <?php echo e($item->sexo ?? ''); ?></p>
                                                                                    </div>
                                                                                    <hr><br>
                                                                                    <div class="col-md-12">
                                                                                        <hr>
                                                                                        <a href="../storage/<?php echo e($item->doc ?? ''); ?>"
                                                                                            target="_blank"
                                                                                            class="btn btn-primary"> Ver
                                                                                            documentação completa do
                                                                                            aluno</a>

                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">fechar</button>
                                                    </div>
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                        <!-- /.modal -->
                                        <div class="modal fade" id="modal-defaultedialuno<?php echo e($item->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">AVISO !</h4>

                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <span class="text-danger">Tem certeza que deseja Excluir o
                                                            aluno: <strong> <?php echo e($item->nome); ?></strong> ?</span>
                                                        <form action="<?php echo e(route('Deletelunos', $item->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>

                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="submit" class="btn btn-danger">Sim</button>
                                                        </form>
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Não</button>

                                                    </div>
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                        <!--ZONA DE EDICAO DE USUARIO--->
                                        <div class="modal fade" id="modal-xl<?php echo e($item->id); ?>">
                                            <div class="modal-dialog modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h6 class="modal-title text-primary">Editando o Aluno:
                                                            <?php echo e($item->nome); ?></h6>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">

                                                        <form id="quickForm" method="post"
                                                            action="<?php echo e(route('Editalunos', $item->id)); ?>"
                                                            enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="card-body">

                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-default"
                                                                    data-dismiss="modal">Fechar</button>
                                                                <button type="submit"
                                                                    class="btn btn-success">Editar</button>
                                                        </form>
                                                    </div>
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="text-danger">Nenhum aluno foi cadastrado!</span>
                                    <?php endif; ?>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Aluno</th>
                                        <th>Tipo</th>
                                        <th>Total</th>
                                        <th>Data e Hora</th>
                                        <th>Ações</th>

                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>

            </div>

            <!--MODAL DOS TIPOS DE CONTAS-->

            <div class="modal fade" id="modal-defaultciclus1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Adicionar Tipo de pagamento</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form id="quickForm" action="<?php echo e(route('addTipoPagamento')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Tipo de pagamento</label>
                                        <input type="text" name="tipo" class="form-control" required>
                                        <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Preço</label>
                                        <input type="number" name="preco" class="form-control" required>
                                        <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Classe</label>
                                        <select name="clace_id" id="" class="form-control" required>
                                            <option value="">Selecionar classe</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if(isset($siculo->curso_id)): ?>
                                                    <option value="<?php echo e($siculo->id); ?>">
                                                        <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($siculo->id); ?>">
                                                        <?php echo e($siculo->nome); ?></option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                        <?php $__errorArgs = ['clace_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">

                                </div>

                        </div>
                        <div class="modal-footer justify-content-between">

                            <button type="submit" class="btn btn-primary">Adicionar</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                            </form>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>


            <!--MODAL DAS ENTRADAS-->
            <div class="modal fade" id="modal-defaultcursos2">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Adicionar Entradas</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form id="quickForm" action="<?php echo e(route('addPagamento')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Aluno</label>
                                        <select class="form-control select2" style="width: 100%;" required
                                            name="aluno_id">
                                            <option selected="selected">Selecione um Aluno</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if($aluno->clace->curso_id > 0): ?>
                                                    <option value="<?php echo e($aluno->id); ?>">
                                                        <?php echo e($aluno->nome . ' ' . $aluno->clace->nome . '-' . $aluno->clace->curso->nome); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($aluno->id); ?>">
                                                        <?php echo e($aluno->nome . '-' . $aluno->clace->nome); ?></option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <span class="text-danger">Nenhum aluno foi encontrado</span>
                                            <?php endif; ?>
                                            <?php $__errorArgs = ['aluno_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Tipos de Pagamento</label>
                                        <select class="form-control select2" style="width: 100%;"
                                            name="tipo_pagamento_id" required>
                                            <option selected="selected">Selecione um Tipo</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if($tipo->clace->curso_id > 0): ?>
                                                    <option value="<?php echo e($tipo->id); ?>">
                                                        <?php echo e($tipo->tipo . ' ' . $tipo->clace->nome . '-' . $tipo->clace->curso->nome); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($tipo->id); ?>">
                                                        <?php echo e($tipo->tipo . '-' . $tipo->clace->nome); ?></option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <span class="text-danger">Nenhum tipo foi encontrado</span>
                                            <?php endif; ?>

                                            <?php $__errorArgs = ['tipo_pagamento_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Meses</label>
                                        <div class="select2-purple">
                                            <select class="select2" multiple="multiple" data-placeholder="Select a State"
                                                data-dropdown-css-class="select2-purple" style="width: 100%;"
                                                name="meses[]">
                                                <option>Selecione os Meses</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($mes->id); ?>"><?php echo e($mes->nome ?? ''); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <span class="text-danger">Nenhum tipo mês foi encontrado</span>
                                                <?php endif; ?>

                                                <?php $__errorArgs = ['meses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </select>
                                        </div>

                                    </div>

                                    <div class="form-group">
                                        <label>Quantidade</label>
                                        <div class="select2-purple">

                                            <input type="number" name="qnt" class="form-control">
                                            <?php $__errorArgs = ['qnt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">

                                    </div>

                                </div>
                                <div class="modal-footer justify-content-between">

                                    <button type="submit" class="btn btn-primary">Adicionar</button>
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                            </form>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>


    </div>

    </section>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttt\resources\views/painel/pagamntos.blade.php ENDPATH**/ ?>