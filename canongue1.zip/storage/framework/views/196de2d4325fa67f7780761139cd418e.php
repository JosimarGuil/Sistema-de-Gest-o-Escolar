

<?php $__env->startSection('title', 'Controle de Pagamentos'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>
                            Gerenciamento de Contas
                        </h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Painel</a></li>
                            <li class="breadcrumb-item active">Gerenciamento de Contas</li>
                        </ol>
                    </div>
                </div>

            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?php echo e($totalEntradas); ?> <sup style="font-size: 25px; "><small
                                            class="text-warning">Kz</small></sup></h3>

                                <p>Entradas</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>

                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?php echo e($totalSaidas); ?><sup style="font-size: 25px; "> <small
                                            class="text-warning">Kz</small></sup></h3>

                                <p>Saídas</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-stats-bars"></i>
                            </div>

                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3 class="text-white"><?php echo e($totalMes); ?> <sup style="font-size: 25px; "><small
                                            class="text-warning">Kz</small></sup></h3>

                                <p class="text-white">Total durante ao Mês</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-person-add"></i>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3 class="text-white"><?php echo e($total - $sub); ?> <sup style="font-size: 25px; "><small
                                            class="text-warning">Kz</small></sup></h3>

                                <p class="text-white">Total</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-person-add"></i>
                            </div>

                        </div>
                    </div>
                    <!-- ./col -->

                </div>
                <!-- /.row -->

            </div>
        </section>

        <!-- Mensagens de retorno -->
        <section class="content-header">
            <div class="container-fluid">
                <?php if(session('sms1')): ?>
                    <div class="" style=" margin-bottom: 10px;">
                        <div class="card">
                            <div class="bg-primary" style="width:100%; margin: auto;
 padding: 10px; ">
                                <span><?php echo e(session('sms1')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms2')): ?>
                    <div class=" " style=" margin-bottom: 10px; ">
                        <div class="card">
                            <div class="bg-danger" style="width:100%; margin: auto;
padding: 10px; ">
                                <span><?php echo e(session('sms2')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms3')): ?>
                    <div class=" " style=" margin-bottom: 10px; border-radius: 5px ">
                        <div class="card">
                            <div class="bg-success" style="width:100%; margin: auto;
           padding: 10px; ">
                                <span><?php echo e(session('sms3')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('warning')): ?>
                    <div class="" style=" margin-bottom: 10px;">
                        <div class="bg-warning" style="width:100%; margin: auto; padding: 10px;">
                            <span><?php echo e(session('warning')); ?></span>
                            <div class="card-tools" style="float: right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content" style="margin-top: 20px">
            <div class="container-fluid">
                <div class="card card-warning card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-edit"></i>
                            Painel de Configuração
                        </h3>
                    </div>
                    <div class="card-body  justify-content-around">
                        <?php if(auth()->user()->perfil == 'SEO' or
                                auth()->user()->perfil == 'Dir Administrativo' or
                                auth()->user()->perfil == 'Dir Geral'): ?>
                            <button type="button" class="btn btn-success toastrDefaultSuccess " data-toggle="modal"
                                data-target="#modal-defaultciclus1">
                                Adicionar Tipos de pagamento
                            </button>
                        <?php endif; ?>
                        <?php if(auth()->user()->perfil == 'Secretário Financeiro' or auth()->user()->perfil == 'Financeiro'): ?>
                            <button type="button" class="btn btn-info  toastrDefaultInfo" data-toggle="modal"
                                data-target="#modal-entradas">
                                Adicionar Entrada
                            </button>

                            <button type="button" class="btn btn-primary  toastrDefaultInfo" data-toggle="modal"
                                data-target="#modal-addsaida1">
                                Adicionar Saídas
                            </button>
                        <?php endif; ?>



                        <div class="text-muted mt-3">

                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.col -->
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Tipos de Busca</h3><br>
                        <hr>


                        <button id="btipo" type="button" class="btn btn-default toastrDefaultError"
                            onclick="verTposPagamentos(this)" style="color: white;background-color:#007bff ">
                            Ver toda Tipos de Pagamentos
                        </button>

                        <button id="bnentrada" type="button" class="btn btn-default toastrDefaultError"
                            onclick="verEntradas(this)">
                            Ver todas entradas
                        </button>
                        <button id="bsaida" type="button" class="btn btn-default toastrDefaultError"
                            onclick="verSaidas(this)">
                            Ver todas saídas
                        </button>

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <!--TABELA DOS TIPOS-->
                        <div id="tipo" style="display: block">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Tipo</th>
                                        <th>Classe</th>
                                        <th>Preço</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($tipo->tipo); ?></td>
                                            <td><?php echo e(isset($tipo->clace->curso_id) ? $tipo->clace->nome . '-' . $tipo->clace->curso->nome : $tipo->clace->nome); ?>

                                            </td>
                                            <td><?php echo e($tipo->preco); ?></td>
                                            <td>----</td>
                                            <td>----</td>
                                            <td>
                                                <?php if(auth()->user()->perfil == 'SEO' or
                                                        auth()->user()->perfil == 'Dir Administrativo' or
                                                        auth()->user()->perfil == 'Dir Geral'): ?>
                                                    <button class="btn btn-success" data-toggle="modal"
                                                        data-target="#modal-defaultedittipo<?php echo e($tipo->id); ?>"><i
                                                            class="fas fa-edit"></i></button>
                                                <?php endif; ?>

                                            </td>

                                        </tr>
                                        <div class="modal fade" id="modal-defaultdeletetipo<?php echo e($tipo->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">AVISO!</h4>

                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <span class="text-danger">Tem certeza que deseja Excluir este
                                                            tipo de pagamento
                                                            <strong> </strong> ?</span>
                                                        <form action="<?php echo e(route('deleteTipoPagamentos', $tipo->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>

                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="submit" class="btn btn-danger">Sim</button>
                                                        </form>
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Não</button>

                                                    </div>
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                        <div class="modal fade" id="modal-defaultedittipo<?php echo e($tipo->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Editar Tipo de Pagamento</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form id="quickForm"
                                                            action="<?php echo e(route('editTipoPagamentos', $tipo->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <div class="card-body">
                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Tipo de
                                                                        pagamento</label>
                                                                    <input type="text" name="tipo"
                                                                        class="form-control" required
                                                                        value="<?php echo e(old('tipo', $tipo->tipo)); ?>">
                                                                    <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Preço</label>
                                                                    <input type="number" name="preco"
                                                                        class="form-control" required
                                                                        value="<?php echo e(old('preco', $tipo->preco)); ?>">
                                                                    <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Classe</label>
                                                                    <select name="clace_id" id=""
                                                                        class="form-control" required>
                                                                        <option value="">Selecionar classe</option>
                                                                        <?php $__empty_2 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                            <?php if(isset($siculo->curso_id)): ?>
                                                                                <option value="<?php echo e($siculo->id); ?>"
                                                                                    <?php echo e($siculo->nome == $tipo->clace->nome ? 'selected' : ''); ?>>
                                                                                    <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?>

                                                                                </option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($siculo->id); ?>"
                                                                                    <?php echo e($siculo->nome == $tipo->clace->nome ? 'selected' : ''); ?>>
                                                                                    <?php echo e($siculo->nome . '-' . $siculo->siculo->nome); ?>

                                                                                </option>
                                                                            <?php endif; ?>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                        <?php endif; ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['clace_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>

                                                            </div>
                                                            <!-- /.card-body -->
                                                            <div class="card-footer">

                                                            </div>

                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="submit" class="btn btn-success">Editar</button>
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Fechar</button>

                                                        </form>
                                                    </div>

                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="text-danger">Nehum foi encontrado</span>
                                    <?php endif; ?>
                                <tfoot>
                                    <tr>
                                        <th>Codigo</th>
                                        <th>Cíclo</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>Ações</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <!--TABELA DAS ENTRADAS DE PAGAMENTO-->
                        <div id="entradas" style="display: none">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th colspan="3">Aluno / Outro</th>
                                        <th colspan="1">Tipo</th>
                                        <th>Meses/Qnt</th>
                                        <th>Data/H</th>
                                        <th>Valor</th>
                                        <th>Ações</th>
                                    </tr>

                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $pamentosEntradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <?php if($item->aluno_id != null): ?>
                                            <th>Turma/C</th>
                                            <td><?php echo e($item->aluno->turma->nome); ?> - <?php echo e($item->aluno->clace->nome); ?></td>
                                            <td><?php echo e($item->aluno->nome); ?></td>
                                            <?php else: ?>
                                              <td colspan="3"><?php echo e($item->outro); ?></td>
                                            <?php endif; ?>
                                            
                                            <td><?php echo e(( $item->tipo_pagamento->tipo)?? 'Outra entrada'); ?></td>
                                            <td>
                                                <?php if(isset($item->tipo_pagamento_id) and ($item->tipo_pagamento->tipo == 'Propina' or $item->tipo_pagamento->tipo == 'propina')): ?>
                                                    <p>
                                                        <?php $__empty_2 = true; $__currentLoopData = $item->meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                            <?php echo e($mes->nome); ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                        <?php endif; ?>
                                                    </p>
                                                <?php else: ?>
                                                    <p>
                                                        <b>Quantidade: </b>
                                                        <?php echo e($item->qnt ?? 0); ?>

                                                    </p>
                                                <?php endif; ?>

                                            </td>
                                            <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                                            <td><?php echo e($item->total); ?></td>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary" data-toggle="modal"
                                                    data-target="#modal-xlver<?php echo e($item->id); ?>"><i
                                                        class="fas fa-eye"></i></button>
                                                <?php if(auth()->user()->perfil == 'Secretário Financeiro' or auth()->user()->perfil == 'Financeiro'): ?>
                                                    <button class="btn btn-success" data-toggle="modal"
                                                        data-target="#modal-defaulteditEntrada<?php echo e($item->id); ?>"><i
                                                            class="fas fa-edit"></i></button>
                                                <?php endif; ?>
                                                <?php if(auth()->user()->perfil == 'SEO' or
                                                        auth()->user()->perfil == 'Dir Administrativo' or
                                                        auth()->user()->perfil == 'Dir Geral'): ?>
                                                    <button class="btn btn-warning" data-toggle="modal"
                                                        data-target="#modal-defaultedialuno<?php echo e($item->id); ?>"
                                                        style="display: inline-block"><i
                                                            class="fas fa-trash"></i></button>
                                                <?php endif; ?>
                                            </td>
                                            </td>
                                        </tr>

                                        <!-- MODAL VER DETALHES DO ALUNO -->
                                        <div class="modal fade" id="modal-xlver<?php echo e($item->id); ?>">
                                            <div class="modal-dialog modal-xl">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h6 class="modal-title text-primary">Faturação de entrada de
                                                            Pagamento:
                                                            <?php echo e($item->nome); ?></h6>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">


                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="col-12 col-md-12">
                                                                    <div class="row">
                                                                        <div class="col-12">
                                                                            <div class="post">
                                                                                <div class="user-block">
                                                                                    <a href="../storage/">
                                                                                        <img class=" "
                                                                                            target="_blank"
                                                                                            src="Kanongue.png"
                                                                                            alt="user image"
                                                                                            style="width: 150px; height: 150px; ">
                                                                                    </a>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <p>
                                                                                        <h3
                                                                                            class="profile-username text-info ">
                                                                                            <?php echo e($item->aluno->nome??'Outro tipo de pagamento'); ?>

                                                                                        </h3>
                                                                                        </p>
                                                                                        <p>

                                                                                            <b>Tipo de Pagamento: </b>
                                                                                            <?php echo e($item->tipo_pagamento->tipo ?? $item->outro); ?>

                                                                                        </p>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <br>
                                                                                        <p>
                                                                                            <b>Classe: </b>
                                                                                            <?php echo e($item->aluno->clace->nome ??'----'); ?>

                                                                                        </p>

                                                                                        <?php if(isset($item->tipo_pagamento_id) and ($item->tipo_pagamento->tipo == 'Propina'
                                                                                         or $item->tipo_pagamento->tipo == 'propina' )): ?>
                                                                                            <p> <b>Meses: </b>
                                                                                                <?php $__empty_2 = true; $__currentLoopData = $item->meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                                    <?php echo e($mes->nome); ?>

                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                                <?php endif; ?>
                                                                                            </p>
                                                                                        <?php else: ?>
                                                                                            <p>
                                                                                                <b>Quantidade: </b>
                                                                                                <?php echo e($item->qnt ?? 0); ?>

                                                                                            </p>
                                                                                        <?php endif; ?>


                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <p>
                                                                                            <b>Turma: </b>
                                                                                            <?php echo e($item->aluno->turma->nome ??'----'); ?>

                                                                                        </p>

                                                                                        <p>
                                                                                            <b>Data de Pagamento: </b>
                                                                                            <?php echo e($item->created_at); ?>

                                                                                        </p>


                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <p>
                                                                                            <b>Total Pago: </b>
                                                                                            <?php echo e($item->total); ?> Kz
                                                                                        </p>

                                                                                    </div>

                                                                                    <br>
                                                                                    <div class="row no-print">

                                                                                        <div class="col-12">
                                                                                            <br><br>
                                                                                            <hr>
                                                                                            <a href="download:/pagamentos"
                                                                                                rel="noopener"
                                                                                                class="btn btn-default"><i
                                                                                                    class="fas fa-print"></i>
                                                                                                Print</a>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                        </div>
                        <!-- /.modal -->
                        <div class="modal fade" id="modal-defaultedialuno<?php echo e($item->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <p class="text-default">Tem certeza que deseja mover este pagamento
                                            para a lixeira? </p>
                                        <form action="<?php echo e(route('DeleteEntradas', $item->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="card-footer">
                                                <button type="submit"
                                                    class="btn btn-warning
                                            text-white">Sim</button>
                                        </form>
                                        <button type="button"
                                            class="btn btn-danger
                                            text-white"
                                            data-dismiss="modal">Não</button>
                                    </div>

                                </div>
                                <div class="modal-footer justify-content-between">

                                    <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                    <!--ZONA DE EDICAO DE USUARIO--->

                    <!--EDITANDO AS ENTRADAS-->
                    <div class="modal fade" id="modal-defaulteditEntrada<?php echo e($item->id); ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Editar entrada de pagamentos</h4>

                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">

                                    <form id="quickForm" action="<?php echo e(route('editPagamento', $item->id)); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label>Aluno</label>
                                                <select class="form-control select2" style="width: 100%;" required
                                                    name="aluno_id">
                                                    <option selected="selected">Selecione um Aluno</option>
                                                    <?php $__empty_2 = true; $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                        <?php if(isset($item->aluno_id) and $item->aluno->nome == $aluno->nome): ?>
                                                            <?php if($aluno->clace->curso_id > 0): ?>
                                                                <option value="<?php echo e($aluno->id); ?>"
                                                                    <?php echo e($item->aluno->id == $aluno->id ? 'selected' : ''); ?>>
                                                                    <?php echo e($aluno->nome . ' ' .$aluno->turma->nome.'-'.$aluno->clace->nome . '-' . $aluno->clace->curso->nome); ?>

                                                                </option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($aluno->id); ?>"
                                                                    <?php echo e($item->aluno->id == $aluno->id ? 'selected' : ''); ?>>
                                                                    <?php echo e($aluno->nome.'-'.$aluno->turma->nome.'-'. $aluno->clace->nome); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                        <span class="text-danger">Nenhum aluno foi encontrado</span>
                                                    <?php endif; ?>
                                                    <?php $__errorArgs = ['aluno_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Tipos de Pagamento</label>
                                                <select class="form-control select2" style="width: 100%;"
                                                    name="tipo_pagamento_id" required>
                                                    <option selected="selected">Selecione um Tipo</option>
                                                    <?php $__empty_2 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    
                                                        <?php if($tipo->clace->curso_id > 0): ?>
                                                            <option value="<?php echo e($tipo->id); ?>"
                                                                <?php echo e($item->tipo_pagamento_id == $tipo->id ? 'selected' : ''); ?>>
                                                                <?php echo e($tipo->tipo . ' ' . $tipo->clace->nome . '-' . $tipo->clace->curso->nome); ?>

                                                            </option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($tipo->id); ?>"
                                                                <?php echo e($item->tipo_pagamento_id == $tipo->id ? 'selected' : ''); ?>>
                                                                <?php echo e($tipo->tipo . '-' . $tipo->clace->nome); ?></option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                        <span class="text-danger">Nenhum tipo foi encontrado</span>
                                                    <?php endif; ?>

                                                    <?php $__errorArgs = ['tipo_pagamento_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Meses</label>
                                                <div class="select2-purple">
                                                    <select class="select2" multiple="multiple"
                                                        data-placeholder="Select a State"
                                                        data-dropdown-css-class="select2-purple" style="width: 100%;"
                                                        name="meses[]">
                                                        <option>Selecione os Meses</option>
                                                        <?php $__empty_2 = true; $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                            <?php $__empty_3 = true; $__currentLoopData = $item->meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                                <option value="<?php echo e($mes->id); ?>"
                                                                    <?php echo e($mes->nome == $me->nome ? 'selected' : ''); ?>>
                                                                    <?php echo e($mes->nome ?? ''); ?>

                                                                </option>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                            <?php endif; ?>

                                                            </option>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                            <span class="text-danger">Nenhum tipo mês foi
                                                                encontrado</span>
                                                        <?php endif; ?>

                                                        <?php $__errorArgs = ['meses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                    </select>
                                                </div>

                                            </div>


                                            <div class="form-group">
                                                <label>Outro Tipo</label>
                                                <div class="select2-purple">
                                                    <input type="text" name="outro" class="form-control"
                                                     maxlength="200" value="<?php echo e(old('outro',$item->outro ??'')); ?>">
                                                    <?php $__errorArgs = ['outro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                
                                            <div class="form-group">
                                                <label>Quantidade</label>
                                                <div class="select2-purple">
                
                                                    <input type="number" name="qnt" class="form-control"
                                                    value="<?php echo e(old('outro')); ?>">
                                                    <?php $__errorArgs = ['qnt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                
                                            <div class="form-group">
                                                <label>Preço</label>
                                                <div class="select2-purple">
                                                    <input type="number" name="preco" class="form-control"
                                                    value="<?php echo e(old('outro',$item->preco)); ?>">
                                                    <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                
                                            <!-- /.card-body -->
                                            <div class="card-footer">

                                            </div>

                                        </div>
                                        <div class="modal-footer justify-content-between">

                                            <button type="submit" class="btn btn-success">Editar</button>
                                            <button type="button" class="btn btn-default"
                                                data-dismiss="modal">Fechar</button>
                                    </form>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-danger">Nenhum aluno foi cadastrado!</span>
                        <?php endif; ?>

                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3">Aluno</th>
                                <th colspan="1">Tipo</th>
                                <th>Meses/Qnt</th>
                                <th>Data/H</th>
                                <th>Valor</th>
                                <th>Ações</th>
                            </tr>
                        </tfoot>
                        </table>
                    </div>


  <!--TABELA DAS SÍDAS DE PAGAMENTOS-->
  <div id="saidas" style="display: none">
    <table id="example1" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th colspan="3"></th>
                <th>Meses/Qnt</th>
                <th>Data/H</th>
                <th>Valor</th>
                <th>Ações</th>
            </tr>

        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pamentosSaidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th>Funcionário/Tipo</th>
                    <td colspan="2">
                        <?php if(isset($item->funcionario->id)): ?>
                            <?php echo e($item->funcionario->nome); ?>

                        <?php else: ?>
                            <?php echo e($item->tipo); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($item->tipo == 'Salário' or $item->tipo == 'Salario' or
                        $item->tipo == 'salário' or $item->tipo == 'salario'): ?>
                            <p>
                                <?php $__empty_2 = true; $__currentLoopData = $item->meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <?php echo e($mes->nome); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <?php endif; ?>
                            </p>
                        <?php else: ?>
                            <p>
                                <b>Quantidade: </b>
                                <?php echo e($item->qnt ?? ''); ?>

                            </p>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(date('m-d-Y', strtotime($item->created_at))); ?></td>
                    <td><?php echo e($item->total); ?></td>
                    <td>
                        <button class="btn btn-primary" data-toggle="modal"
                            data-target="#modal-xlver<?php echo e($item->id); ?>"><i class="fas fa-eye"></i></button>
                        <?php if(auth()->user()->perfil == 'Secretário Financeiro' or auth()->user()->perfil == 'Financeiro'): ?>
                            <button class="btn btn-success" data-toggle="modal"
                                data-target="#modal-defaulteditEntrada<?php echo e($item->id); ?>"><i
                                    class="fas fa-edit"></i></button>
                        <?php endif; ?>
                        <?php if(auth()->user()->perfil == 'SEO' or
                                auth()->user()->perfil == 'Dir Administrativo' or
                                auth()->user()->perfil == 'Dir Geral'): ?>
                            <button class="btn btn-warning" data-toggle="modal"
                                data-target="#modal-defaultedialuno<?php echo e($item->id); ?>"
                                style="display: inline-block"><i class="fas fa-trash"></i></button>
                        <?php endif; ?>
                    </td>
                </tr>

                <!-- MODAL VER DETALHES DO ALUNO -->
                <div class="modal fade" id="modal-xlver<?php echo e($item->id); ?>">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h6 class="modal-title text-primary">Faturação de entrada de
                                    Pagamento:
                                    <?php echo e($item->nome); ?></h6>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">


                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12 col-md-12">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="post">
                                                        <div class="user-block">
                                                            <a href="../storage/">
                                                                <img class=" " target="_blank"
                                                                    src="Kanongue.png" alt="user image"
                                                                    style="width: 150px; height: 150px; ">
                                                            </a>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <p>
                                                                <h3 class="profile-username text-info ">
                                                                    
                                                                </h3>
                                                                </p>
                                                                <p>

                                                                    <b>Tipo de Pagamento: </b>
                                                                  
                                                                </p>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <br>
                                                                <p>
                                                                    <b>Classe: </b>
                                                                  
                                                                </p>

                                                                <?php if($item->tipo == 'Propina' or $item->tipo == 'propina'): ?>
                                                                    <p> <b>Meses: </b>
                                                                        <?php $__empty_2 = true; $__currentLoopData = $item->meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                            <?php echo e($mes->nome); ?>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                        <?php endif; ?>
                                                                    </p>
                                                                <?php else: ?>
                                                                    <p>
                                                                        <b>Quantidade: </b>
                                                                        <?php echo e($item->qnt ?? ''); ?>

                                                                    </p>
                                                                <?php endif; ?>


                                                            </div>
                                                            <div class="col-md-6">
                                                                <p>
                                                                    <b>Turma: </b>
                                                                   
                                                                </p>

                                                                <p>
                                                                    <b>Data de Pagamento: </b>
                                                                    <?php echo e($item->created_at); ?>

                                                                </p>


                                                            </div>
                                                            <div class="col-md-6">
                                                                <p>
                                                                    <b>Total Pago: </b>
                                                                    <?php echo e($item->total); ?> Kz
                                                                </p>

                                                            </div>

                                                            <br>
                                                            <div class="row no-print">

                                                                <div class="col-12">
                                                                    <br><br>
                                                                    <hr>
                                                                    <a href="download:/pagamentos" rel="noopener"
                                                                        class="btn btn-default"><i
                                                                            class="fas fa-print"></i>
                                                                        Print</a>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
             </div>


    <!-- /.modal -->
    <div class="modal fade" id="modal-defaultedialuno<?php echo e($item->id); ?>">
     <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-default">Tem certeza que deseja mover este pagamento
                    para a lixeira? </p>
                <form action="<?php echo e(route('DeleteEntradas', $item->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-warning
                    text-white">Sim</button>
                </form>
                <button type="button" class="btn btn-danger
                    text-white"
                    data-dismiss="modal">Não</button>
            </div>

        </div>
        <div class="modal-footer justify-content-between">

            <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
        </div>
     </div>
      <!-- /.modal-content -->
   </div>
     <!-- /.modal-dialog -->
    </div>
     <!--ZONA DE EDICAO DE USUARIO--->

     <!--EDITANDO AS ENTRADAS-->
<div class="modal fade" id="modal-defaulteditEntrada<?php echo e($item->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Editar entrada de pagamentos</h4>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="quickForm" action="<?php echo e(route('editPagamento', $item->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Aluno</label>
                            <select class="form-control select2" style="width: 100%;" required name="aluno_id">
                                <option selected="selected">Selecione um Aluno</option>
                             
                               
                        </div>
                        <div class="form-group">
                            <label>Tipos de Pagamento</label>
                            <select class="form-control select2" style="width: 100%;" name="tipo_pagamento_id"
                                required>
                                <option selected="selected">Selecione um Tipo</option>
                             
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Meses</label>
                            <div class="select2-purple">
                                <select class="select2" multiple="multiple" data-placeholder="Select a State"
                                    data-dropdown-css-class="select2-purple" style="width: 100%;" name="meses[]">
                                    <option>Selecione os Meses</option>
                                   
                                </select>
                            </div>

                        </div>

                        <div class="form-group">
                            <label>Quantidade</label>
                            <div class="select2-purple">

                                <input type="number" name="qnt" class="form-control" value="">
                                <?php $__errorArgs = ['qnt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">

                        </div>

                    </div>
                    <div class="modal-footer justify-content-between">

                        <button type="submit" class="btn btn-success">Editar</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <span class="text-danger">Nenhum aluno foi cadastrado!</span>
    <?php endif; ?>

    </tbody>
    <tfoot>
        <tr>
            <th colspan="3"></th>
            <th>Meses/Qnt</th>
            <th>Data/H</th>
            <th>Valor</th>
            <th>Ações</th>
         </tr>
       </tfoot>
      </table>
</div>









                </div>
                <!-- /.card-body -->
            </div>

    </div>

    <!--MODAL DAS ENTRADAS CONTAS-->

    <div class="modal fade" id="modal-entradas">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Pagamentos</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="quickForm" action="<?php echo e(route('addPagamento')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Aluno</label>
                                <select class="form-control select2" style="width: 100%;" required name="aluno_id">
                                    <option selected="selected">Selecione um Aluno</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if($aluno->clace->curso_id > 0): ?>
                                            <option value="<?php echo e($aluno->id); ?>">
                                                <?php echo e($aluno->nome . ' ' . $aluno->clace->nome . '-' . $aluno->clace->curso->nome); ?>

                                            </option>
                                        <?php else: ?>
                                            <option value="<?php echo e($aluno->id); ?>">
                                                <?php echo e($aluno->nome . '-' . $aluno->clace->nome); ?></option>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="text-danger">Nenhum aluno foi encontrado</span>
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['aluno_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Tipos de Pagamento</label>
                                <select class="form-control select2" style="width: 100%;" name="tipo_pagamento_id"
                                    required>
                                    <option selected="selected">Selecione um Tipo</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if($tipo->clace->curso_id > 0): ?>
                                            <option value="<?php echo e($tipo->id); ?>">
                                                <?php echo e($tipo->tipo . ' ' . $tipo->clace->nome . '-' . $tipo->clace->curso->nome); ?>

                                            </option>
                                        <?php else: ?>
                                            <option value="<?php echo e($tipo->id); ?>">
                                                <?php echo e($tipo->tipo . '-' . $tipo->clace->nome); ?></option>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="text-danger">Nenhum tipo foi encontrado</span>
                                    <?php endif; ?>

                                    <?php $__errorArgs = ['tipo_pagamento_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Meses</label>
                                <div class="select2-purple">
                                    <select class="select2" multiple="multiple" data-placeholder="Select a State"
                                        data-dropdown-css-class="select2-purple" style="width: 100%;" name="meses[]">
                                        <option>Selecione os Meses</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($mes->id); ?>"><?php echo e($mes->nome ?? ''); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-danger">Nenhum tipo mês foi encontrado</span>
                                        <?php endif; ?>

                                        <?php $__errorArgs = ['meses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </select>
                                </div>

                            </div>
                            
                            <div class="form-group">
                                <label>Outro Tipo</label>
                                <div class="select2-purple">
                                    <input type="text" name="outro" class="form-control" maxlength="200">
                                    <?php $__errorArgs = ['outro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Quantidade</label>
                                <div class="select2-purple">

                                    <input type="number" name="qnt" class="form-control">
                                    <?php $__errorArgs = ['qnt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Preço</label>
                                <div class="select2-purple">
                                    <input type="number" name="preco" class="form-control">
                                    <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                </div>
                <div class="modal-footer justify-content-between">
                    <button type="submit" class="btn btn-primary">Adicionar</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>




    <div class="modal fade" id="modal-defaultciclus1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Tipo de pagamento</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="quickForm" action="<?php echo e(route('addTipoPagamento')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tipo de pagamento</label>
                                <input type="text" name="tipo" class="form-control" required>
                                <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Preço</label>
                                <input type="number" name="preco" class="form-control" required>
                                <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Classe</label>
                                <select name="clace_id" id="" class="form-control" required>
                                    <option value="">Selecionar classe</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if(isset($siculo->curso_id)): ?>
                                            <option value="<?php echo e($siculo->id); ?>">
                                                <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($siculo->id); ?>">
                                                <?php echo e($siculo->nome); ?></option>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['clace_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">

                        </div>

                </div>
                <div class="modal-footer justify-content-between">

                    <button type="submit" class="btn btn-primary">Adicionar</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>






    <!---MODAL DAS SAIDAS--->
    <div class="modal fade" id="modal-addsaida1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Saídas</h4>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form id="quickForm" action="<?php echo e(route('addSaida')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Funcionário</label>
                                <select class="form-control select2" style="width: 100%;" required name="funcionario_id">
                                    <option selected="selected">Selecione um Funcionarios</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $funcionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $func): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($func->id); ?>">
                                            <?php echo e($func->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="text-danger">Nenhum funcionario foi encontrado</span>
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['funcionario_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Meses</label>
                                <div class="select2-purple">
                                    <select class="select2" multiple="multiple" data-placeholder="Select a State"
                                        data-dropdown-css-class="select2-purple" style="width: 100%;" name="meses[]">
                                        <option>Selecione os Meses</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($mes->id); ?>"><?php echo e($mes->nome ?? ''); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-danger">Nenhum tipo mês foi encontrado</span>
                                        <?php endif; ?>

                                    </select>
                                    <?php $__errorArgs = ['meses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Tipos de Saídas</label>

                                <input type="text" class="form-control" required name="tipo">

                                <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group">
                                <label>Quantidade</label>

                                <input type="number" class="form-control" name="qnt">

                                <?php $__errorArgs = ['qnt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="form-group">
                                <label>Preço</label>

                                <input type="number" class="form-control" name="preco">

                                <?php $__errorArgs = ['preco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>


                            <div class="form-group">
                                <label>Descrição</label>
                                <div class="select2-purple">

                                    <textarea name="descri" id="" cols="5" rows="3" class="form-control"></textarea>
                                    <?php $__errorArgs = ['descri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">

                            </div>

                        </div>
                        <div class="modal-footer justify-content-between">

                            <button type="submit" class="btn btn-primary">Adicionar</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                    </form>

                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>






  
    
  </div>
   
      </div>

    </div>







    </section>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('tema.tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\canongue\resources\views/painel/pagamentos.blade.php ENDPATH**/ ?>