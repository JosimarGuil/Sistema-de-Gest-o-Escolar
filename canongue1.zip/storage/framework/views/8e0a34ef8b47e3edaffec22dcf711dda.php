
 <?php $__env->startSection('title','listar alunos'); ?>
 <?php $__env->startSection('content'); ?>
    <h1>TODOS ALUNOS</h1>
    <a href="/addaluno">Cadastrar alunos</a>
    <hr>
    <ul>
        <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elementos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($elementos->nome); ?> <?php echo e($elementos->idade); ?> <?php echo e($elementos->curso); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</body>
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste\resources\views/alunos/list.blade.php ENDPATH**/ ?>