

<?php $__env->startSection('title', 'Configurações da Escola'); ?>



<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>
                            Gerenciamento de Contas

                        </h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Painel</a></li>
                            <li class="breadcrumb-item active">Gerenciamento de Contas</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <?php if(session('sms1')): ?>
            <div class="container " style=" margin-bottom: 10px;">
                <div class="card">
                    <div class="bg-primary" style="width:100%; margin: auto;
     padding: 10px; ">
                        <span><?php echo e(session('sms1')); ?></span>
                        <div class="card-tools" style="float: right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
        <?php endif; ?>
        <?php if(session('warning')): ?>
            <div class="container " style=" margin-bottom: 10px;">
                <div class="card">
                    <div class="bg-danger" style="width:100%; margin: auto;
                      padding: 10px; ">
                        <span><?php echo e(session('warning')); ?></span>
                        <div class="card-tools" style="float: right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
        <?php endif; ?>
        <?php if(session('sms2')): ?>
            <div class="container " style=" margin-bottom: 20px; ">
                <div class="card">
                    <div class="bg-danger" style="width:100%; margin: auto;
 padding: 10px; ">
                        <span><?php echo e(session('sms2')); ?></span>
                        <div class="card-tools" style="float: right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
        <?php endif; ?>
        <?php if(session('sms3')): ?>
            <div class="container " style=" margin-bottom: 10px; border-radius: 5px ">
                <div class="card">
                    <div class="bg-success" style="width:100%; margin: auto;
               padding: 10px; ">
                        <span><?php echo e(session('sms3')); ?></span>
                        <div class="card-tools" style="float: right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
        <?php endif; ?>
     <!-- Main content -->
     <section class="content">
        <div class="container-fluid">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-lg-4 col-6">
              <!-- small box -->
              <div class="small-box bg-info">
                <div class="inner">
                  <h3>150  <sup style="font-size: 25px; "><small class="text-warning">Kz</small></sup></h3>
  
                  <p>Entradas</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
               
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-4 col-6">
              <!-- small box -->
              <div class="small-box bg-success">
                <div class="inner">
                  <h3>444  <sup style="font-size: 25px; "><small class="text-warning">Kz</small></sup></h3>
  
                  <p>Saídas</p>
                </div>
                <div class="icon">
                  <i class="ion ion-stats-bars"></i>
                </div>
               
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-4 col-6">
              <!-- small box -->
              <div class="small-box bg-danger">
                <div class="inner">
                  <h3 class="text-white">66  <sup style="font-size: 25px; "><small class="text-warning">Kz</small></sup></h3>
  
                  <p class="text-white">Total</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
               
              </div>
            </div>
            <!-- ./col -->
           
          </div>
          <!-- /.row -->
         
        </div>
      </section>
        <section class="content" style="margin-top: 10px">
            <div class="container-fluid">

                <div class="card card-warning card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-edit"></i>
                            Painel de Configuração
                        </h3>
                    </div>
                    <div class="card-body  justify-content-around">
                       
                        <button type="button" class="btn btn-success toastrDefaultSuccess " data-toggle="modal"
                            data-target="#modal-defaultciclus1">
                            Adicionar Tipos de pagamento
                        </button>
                    
                        <button type="button" class="btn btn-info  toastrDefaultInfo" data-toggle="modal"
                            data-target="#modal-defaultcursos2">
                            Adicionar Entrada
                        </button>

                        <button type="button" class="btn btn-primary  toastrDefaultInfo" data-toggle="modal"
                           data-target="#modal-defaultcursos2">
                             Adicionar Saídas
                       </button>
                      

                        <div class="text-muted mt-3">
                            Somente o Director geral tem esse Acesso
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.col -->



            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Tipos de Busca</h3><br>
                        <hr>

                        
                            <button id="bci" type="button" class="btn btn-default toastrDefaultError"
                                onclick=" siculos(this)" style="color: white;background-color:#007bff ">
                                Ver todas entradas
                            </button>
 
                        <button id="bcu" type="button" class="btn btn-default toastrDefaultError"
                            onclick=" cursos(this)">
                            Ver todos saídas
                        </button>
 
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <!--TABELA DOS SICULOS-->
                        <div id="siculo" style="display: block">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Codigo</th>
                                        <th>Cíclo</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td>----</td>
                                            <th>----</th>
                                            <th>----</th>
                                            <td>

                                                <button class="btn btn-success" data-toggle="modal"
                                                    data-target="#modal-defaulteditciclu"><i
                                                        class="fas fa-edit"></i></button>


                                                <button class="btn btn-danger" data-toggle="modal"
                                                    data-target="#modal-defaulteditciclu1"
                                                    style="display: inline-block"><i class="fas fa-trash"></i></button>

                                            </td>

                                        </tr>
                                        <div class="modal fade" id="modal-defaulteditciclu1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">AVISO !</h4>

                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <span class="text-danger">Tem certeza que deseja Excluir o cíclo:
                                                            <strong> </strong> ?</span>
                                                        <form action=""
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>

                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="submit" class="btn btn-danger">Sim</button>
                                                        </form>
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Não</button>

                                                    </div>
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                        <div class="modal fade" id="modal-defaulteditciclu">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Editar Cíclo</h4>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form id="quickForm"
                                                            action=""
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="card-body">
                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Cíclo</label>
                                                                    <select name="ciclu" class="form-control"
                                                                        id="nome" required>
                                                                        <option value="">Selecione um Cíclo</option>
                                                                        <option value="Ensino Primário">
                                                                           
                                                                            Ensino Primário</option>
                                                                        <option value="Ensino de Base"
                                                                          >
                                                                            Ensino de Base</option>
                                                                    </select>

                                                                    <?php $__errorArgs = ['ciclu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <!-- /.card-body -->
                                                            <div class="card-footer">
                                                                <button type="submit" class="btn btn-success"><i
                                                                        class="fas fa-edit"></i></button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <button type="button" class="btn btn-default"
                                                            data-dismiss="modal">Fechar</button>

                                                    </div>
                                                </div>
                                                <!-- /.modal-content -->
                                            </div>
                                            <!-- /.modal-dialog -->
                                        </div>
                                    
                                <tfoot>
                                    <tr>
                                        <th>Codigo</th>
                                        <th>Cíclo</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>Ações</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>


                    </div>
                    <!-- /.card-body -->
                </div>

            </div>

            <!--MODAL DOS SICULOS-->

            <div class="modal fade" id="modal-defaultciclus1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Adicionar Cíclo</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form id="quickForm" action="<?php echo e(route('addSiculo')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Cíclo</label>
                                        <select name="ciclu" class="form-control" id="nome" required>
                                            <option value="">Selecione um Cíclo</option>
                                            <option value="Ensino Primário">Ensino Primário</option>
                                            <option value="Primeiro Cíclo">Primeiro Cíclo</option>
                                        </select>

                                        <?php $__errorArgs = ['ciclu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">

                                </div>

                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary">Adicionar</button>
                            </form>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>

            

    </div>

    </section>

    </div>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste\resources\views/painel/pagamntos.blade.php ENDPATH**/ ?>