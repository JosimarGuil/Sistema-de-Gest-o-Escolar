

<?php $__env->startSection('title', 'Gestão dos alunos do Canongue'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Getão dos alunos</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Painel</a></li>
                            <li class="breadcrumb-item active">Alunos</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Mensagens de retorno -->
        <section class="content-header">
            <div class="container-fluid">
                <?php if(session('sms1')): ?>
                    <div class="" style=" margin-bottom: 5px;">
                        <div class="card">
                            <div class="bg-primary" style="width:100%; margin: auto;padding: 10px; ">
                                <span><?php echo e(session('sms1')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms2')): ?>
                    <div class=" " style=" margin-bottom: 5px; ">
                        <div class="card">
                            <div class="bg-warning" style="width:100%; margin: auto;padding: 10px; ">
                                <span><?php echo e(session('sms2')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms3')): ?>
                    <div class=" " style=" margin-bottom: 5px; border-radius: 5px ">
                        <div class="card">
                            <div class="bg-success" style="width:100%; margin: auto;padding: 10px; ">
                                <span><?php echo e(session('sms3')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('warning')): ?>
                    <div class="" style=" margin-bottom: 10px;">
                        <div class="bg-danger" style="width:100%; margin: auto;padding: 10px;">
                            <span><?php echo e(session('warning')); ?></span>
                            <div class="card-tools" style="float: right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div><!-- /.container-fluid -->
        </section>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card card-warning card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-edit"></i>
                            Painel de gestão do aluno
                        </h3>
                    </div>
                    <div class="card-body">
                        <?php if(auth()->user()->perfil=='Secretário Geral' or
                        auth()->user()->perfil=='Secretário Pedagógico' or
                        auth()->user()->perfil=='Dr Pedagógico'): ?>
                        <div class="col-12">

                            <button type="button" class="btn btn-info toastrDefaultInfo " data-toggle="modal"
                                data-target="#modal-defaultciclus1" onclick="AddAlunos()" id="badd">
                                Abrir formulário de Cadastro de alunos no sistema
                            </button>

                            <button type="button" class="btn btn-primary toastrDefaultWarning " data-toggle="modal"
                                data-target="#modal-defaultciclus1" onclick="Verlunos()" style="display: none"
                                id="bver">
                                Listar todos alunos cadastrados no sistema
                            </button>

                        </div>  
                        <?php endif; ?>
                        


                    </div>
                    <!-- /.card -->
                </div>
            </div>

            <!---ZONA DO FORMULARIO DE ADICAO DE ALUNOS---->
            <section class="content" id="addalunos" style="display: none">
                <div class="container-fluid">
                    <div class="row">
                        <!-- left column -->
                        <div class="col-md-12">
                            <!-- jquery validation -->
                            <div class="card card-default">
                                <div class="card-header">
                                    <h3 class="card-title">Cadastrar Alunos</h3>
                                </div>
                                <!-- /.card-header -->
                                <!-- form start -->
                                <form id="quickForm" method="post" action="<?php echo e(route('Addalunos')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Nome Completo*</label>
                                            <input type="text" maxlength="50" minlength="5" name="nome"
                                                class="form-control" id="exampleInputEmail1" required
                                                placeholder="Nome Completo" value="<?php echo e(old('nome')); ?>">
                                            <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Sexo*</label><br>
                                            <label for="exampleInputEmail1">Masculino</label>
                                            <input type="radio" name="sexo" id="" value="Masculino">
                                            <label for="exampleInputEmail1">Femenino</label>
                                            <input type="radio" name="sexo" id="" value=" Femenino">
                                            <span>Selecione o sexo do aluno</span>
                                            <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group ">
                                            <label for="exampleInputPassword1">Data de Nascimento*</label>
                                            <input type="date" name="data" required class="form-control"
                                                id="exampleInputPassword1" value="<?php echo e(old('data')); ?>"
                                                placeholder="Data de Nascimento">
                                            <?php $__errorArgs = ['data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group ">
                                            <label for="exampleInputPassword1">Localidade*</label>
                                            <input type="map" name="localiza" required class="form-control"
                                                id="exampleInputPassword1" placeholder="Localidade" minlength="15"
                                                maxlength="35" value="<?php echo e(old('localiza')); ?>">
                                            <?php $__errorArgs = ['localiza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Email</label>
                                            <input type="email"  name="email"
                                                class="form-control" id="exampleInputEmail1" value="<?php echo e(old('email')); ?>"
                                                placeholder="E-mail">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group ">
                                            <label for="exampleInputPassword1">Telefone*</label>
                                            <input type="tel" name="fone" required class="form-control"
                                                id="exampleInputPassword1" value="<?php echo e(old('fone')); ?>"
                                                placeholder="Telefone" minlength="9" maxlength="9">
                                            <?php $__errorArgs = ['fone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group ">
                                            <label for="exampleInputPassword1">Classe*</label>
                                            <select name="classe_id" id="" required class="form-control">
                                                <option value="" selected="selected" data-select2-id="11">Selecionar
                                                    uma Classe</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php if(isset($siculo->curso_id) and $siculo->curso_id != ''): ?>
                                                        <option value="<?php echo e($siculo->id); ?>" data-select2-id="33">
                                                            <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($siculo->id); ?>">
                                                            <?php echo e($siculo->nome); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                                <?php $__errorArgs = ['classe_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </select>
                                        </div>
                                        <div class="form-group ">
                                            <label for="exampleInputPassword1">Turma*</label>
                                            <select name="turma_id" id="" required class="form-control">

                                                <option value="">Selecionar uma Turma</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $turmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($turma->id); ?>">
                                                        <?php echo e($turma->clace->curso_id > 0
                                                            ? $turma->nome . '  ' . $turma->clace->nome . '-' . $turma->clace->curso->nome
                                                            : $turma->nome . '  ' . $turma->clace->nome); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                                <?php $__errorArgs = ['turma_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Foto Meio Corpo*</label>
                                            <input type="file" maxlength="255"  name="img"
                                                class="form-control" id="exampleInputEmail1" required
                                                placeholder="Nome Completo">
                                            <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Documentação Completa*</label>
                                            <input type="file" maxlength="255"  name="doc"
                                                class="form-control" id="exampleInputEmail1" required
                                                placeholder="Nome Completo">
                                            <?php $__errorArgs = ['doc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Registrar Aluno</button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card -->
                        </div>
                        <!--/.col (left) -->
                        <!-- right column -->
                        <div class="col-md-6">

                        </div>
                        <!--/.col (right) -->
                    </div>
                    <!-- /.row -->
                </div><!-- /.container-fluid -->
            </section>



            <!--TABELA DE LISTAGEM DOS ALUNOS-->

            <div class="container-fluid" id="listalunos">
                <div class="row">
                    <div class="col-12">


                        <div class="card">
                            <div class="card-header">

                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Numero</th>
                                            <th>Nome Completo</th>
                                            <th>Classe</th>
                                            <th>Sala</th>
                                            <th>Turma</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($item->nome); ?></td>
                                                <td><?php echo e($item->clace->nome); ?></td>
                                                <td><?php echo e($item->sala->sala); ?></td>
                                                <td>
                                                    <?php echo e($item->curso_id > 0
                                                        ? $item->turma->nome . '  ' . $item->turma->clace->nome . '-' . $item->turma->clace->curso->nome
                                                        : $item->turma->nome . '  ' . $item->turma->clace->nome . '-' . $item->turma->clace->siculo->nome); ?>

                                                </td>
                                                <td>
                                                    <button class="btn btn-primary" data-toggle="modal"
                                                        data-target="#modal-lgDetalhes<?php echo e($item->id); ?>"><i
                                                            class="fas fa-eye"></i></button>
                                                 <?php if(auth()->user()->perfil=='Secretário Geral' or
                                                 auth()->user()->perfil=='Secretário Pedagógico' or
                                                 auth()->user()->perfil=='Dr Pedagógico'): ?>
                                                     
                                                     <button class="btn btn-success" data-toggle="modal"
                                                        data-target="#modal-xl<?php echo e($item->id); ?>"><i
                                                            class="fas fa-edit"></i></button>

                                                    <button class="btn btn-warning" data-toggle="modal"
                                                        data-target="#modal-defaultedialuno<?php echo e($item->id); ?>"
                                                        style="display: inline-block"><i
                                                            class="fas fa-trash"></i></button>
                                                 <?php endif; ?>
                                                    
                                                </td>
                                                </td>
                                            </tr>
                                            </tr>
                                            <!-- MODAL VER DETALHES DO ALUNO -->

                                            <div class="modal fade" id="modal-lgDetalhes<?php echo e($item->id); ?>">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Detalhes do aluno</h4>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-12 col-md-12">
                                                                        <div class="row">
                                                                            <div class="col-12">
                                                                                <div class="post">
                                                                                    <div class="user-block">
                                                                                        <a
                                                                                            href="../storage/<?php echo e($item->img ?? ''); ?>">
                                                                                            <img class=" img-bordered-sm"
                                                                                                target="_blank"
                                                                                                src="../storage/<?php echo e($item->img ?? ''); ?>"
                                                                                                alt="user image"
                                                                                                style="width: 150px; height: 150px; border-color:rgb(0, 174, 255);
                                                                             border-radius: 5px">
                                                                             <img class=" "
                                                                             src="kanongue.png"
                                                                             target="_blank"
                                                                             alt="user image"
                                                                             style="width: 100px; height: 100px; float: right">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-md-6">
                                                                                            <p>
                                                                                            <h3
                                                                                                class="profile-username text-info ">
                                                                                                <?php echo e($item->nome ?? ''); ?></h3>
                                                                                            </p>
                                                                                            <p><i
                                                                                                    class="fas fa-user text-info">
                                                                                                    Gênero: </i>
                                                                                                <?php echo e($item->sexo ?? ''); ?></p>
                                                                                        </div>
                                                                                        <div class="col-md-6">
                                                                                            <br>
                                                                                            <p><i
                                                                                                    class="fas fa-envelope text-info ">
                                                                                                    E-mail: </i>
                                                                                                <?php echo e($item->email ?? ''); ?></p>
                                                                                            <p><i
                                                                                                    class="fas fa-map-marker-alt mr-1 text-info">
                                                                                                    Morada: </i>
                                                                                                <?php echo e($item->localiza ?? ''); ?>

                                                                                            </p>
                                                                                        </div>
                                                                                        <div class="col-md-6">
                                                                                            <p><i
                                                                                                    class="fas fa-phone text-info">
                                                                                                    Telefone: </i>
                                                                                                <?php echo e($item->fone ?? ''); ?></p>
                                                                                            <?php if($item->whatsapp): ?>
                                                                                                <p><i
                                                                                                        class="fas fa-phone text-info">
                                                                                                        Whatsapp: </i>
                                                                                                    <?php echo e($item->whatsapp ?? ''); ?>

                                                                                                </p>
                                                                                            <?php endif; ?>
                                                                                            <p><i
                                                                                                    class="far fa-circle text-info">
                                                                                                    Código da Classe: </i>
                                                                                                <?php echo e($item->clace->id ?? ''); ?>

                                                                                            </p>
                                                                                        </div>

                                                                                        <div class="col-md-6">
                                                                                            <p><i
                                                                                                    class="nav-icon far fa-circle text-info">
                                                                                                    Curso / Cíclo: </i>
                                                                                                <?php echo e($item->siculo->nome ?? $item->curso->nome); ?>

                                                                                            </p>
                                                                                            <p><i
                                                                                                    class="nav-icon far fa-circle text-info">
                                                                                                    Código da Turma: </i>
                                                                                                <?php echo e($item->turma->id ?? ''); ?>

                                                                                            </p>
                                                                                        </div>
                                                                                        <br><br><br>
                                                                                        <div class="col-md-12">
                                                                                            <br>
                                                                                            <a href="../storage/<?php echo e($item->doc ?? ''); ?>"
                                                                                                target="_blank"
                                                                                                class="btn btn-info"> Ver
                                                                                                documentação completa do
                                                                                                aluno</a>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">fechar</button>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                        </div>
                                            <!-- /.modal -->
                                            <div class="modal fade" id="modal-defaultedialuno<?php echo e($item->id); ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>

                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p class="text-default">Tem certeza que deseja mover este este para a lixeira? </p>
                                                            <form action="<?php echo e(route('Deletelunos', $item->id)); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <div class="card-footer">
                                                                    <button type="submit" class="btn btn-warning
                                                                text-white">Sim</button>
                                                                </form>
                                                                <button type="button" class="btn btn-danger
                                                                text-white"
                                                                    data-dismiss="modal">Não</button>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>
                                            <!--ZONA DE EDICAO DE USUARIO--->
                                            <div class="modal fade" id="modal-xl<?php echo e($item->id); ?>">
                                                <div class="modal-dialog modal-xl">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h6 class="modal-title text-primary">Editando o Aluno:
                                                                <?php echo e($item->nome); ?></h6>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                            <form id="quickForm" method="post"
                                                                action="<?php echo e(route('Editalunos', $item->id)); ?>"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="card-body">
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Nome
                                                                            Completo*</label>
                                                                        <input type="text" maxlength="50"
                                                                            min="5" name="nome"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            required placeholder="Nome Completo"
                                                                            value="<?php echo e(old('nome', $item->nome)); ?>">
                                                                        <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="">Sexo*</label><br>
                                                                        <label for="exampleInputEmail1">Masculino</label>
                                                                        <input type="radio" name="sexo"
                                                                            id="" value="Masculino"
                                                                            <?php echo e($item->sexo == 'Masculino' ? 'checked' : ''); ?>>
                                                                        <label for="exampleInputEmail1">Femenino</label>
                                                                        <input type="radio" name="sexo"
                                                                            id="" value=" Femenino"
                                                                            <?php echo e($item->sexo == 'Femenino' ? 'checked' : ''); ?>>
                                                                        <span>Selecione o sexo do aluno</span>
                                                                        <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Data de
                                                                            Nascimento*</label>
                                                                        <input type="date" name="data" required
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            value="<?php echo e(old('data', $item->data)); ?>"
                                                                            placeholder="Data de Nascimento">
                                                                        <?php $__errorArgs = ['data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label
                                                                            for="exampleInputPassword1">Localidade*</label>
                                                                        <input type="map" name="localiza" required
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            placeholder="Localidade" minlength="15"
                                                                            maxlength="35"
                                                                            value="<?php echo e(old('localiza', $item->localiza)); ?>">
                                                                        <?php $__errorArgs = ['localiza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Email</label>
                                                                        <input type="email" maxlength="50"
                                                                            minlength="5" name="email"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            value="<?php echo e(old('email', $item->email)); ?>"
                                                                            placeholder="E-mail">
                                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label
                                                                            for="exampleInputPassword1">Telefone*</label>
                                                                        <input type="tel" name="fone" required
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            value="<?php echo e(old('fone', $item->fone)); ?>"
                                                                            placeholder="Telefone" min="9"
                                                                            max="9">
                                                                        <?php $__errorArgs = ['fone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Whatsapp</label>
                                                                        <input type="tel" name="what"
                                                                            class="form-control"
                                                                            id="exampleInputPassword1"
                                                                            value="<?php echo e(old('what', $item->what)); ?>"
                                                                            placeholder="Whatsapp" min="9"
                                                                            max="9">
                                                                        <?php $__errorArgs = ['what'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Classe*</label>
                                                                        <select name="classe_id" id="" required
                                                                            class="form-control">
                                                                            <option value="">Selecior uma Classe
                                                                            </option>
                                                                            <?php $__empty_2 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                <?php if(isset($siculo->curso_id) and $siculo->curso_id != ''): ?>
                                                                                    <option value="<?php echo e($siculo->id); ?>"
                                                                                        <?php echo e($siculo->nome == $item->clace->nome ? 'selected' : ''); ?>>
                                                                                        <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?>

                                                                                    </option>
                                                                                <?php else: ?>
                                                                                    <option value="<?php echo e($siculo->id); ?>"
                                                                                        <?php echo e($siculo->nome == $item->clace->nome ? 'selected' : ''); ?>>
                                                                                        <?php echo e($siculo->nome . '-' . $siculo->siculo->nome); ?>

                                                                                    </option>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                            <?php endif; ?>
                                                                            <?php $__errorArgs = ['classe_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </select>
                                                                    </div>

                                                                    <div class="form-group ">
                                                                        <label for="exampleInputPassword1">Turma*</label>
                                                                        <select name="turma_id" id="" required
                                                                            class="form-control">

                                                                            <option value="">Selecionar uma Turma
                                                                            </option>
                                                                            <?php $__empty_2 = true; $__currentLoopData = $turmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                <option value="<?php echo e($turma->id); ?>"
                                                                                    <?php echo e($turma->nome == $item->turma->nome ? 'selected' : ''); ?>>
                                                                                    <?php echo e($turma->clace->curso_id > 0
                                                                                        ? $turma->nome . '  ' . $turma->clace->nome . '-' . $turma->clace->curso->nome
                                                                                        : $turma->nome . '  ' . $turma->clace->nome . '-' . $turma->clace->siculo->nome); ?>

                                                                                </option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                            <?php endif; ?>
                                                                            <?php $__errorArgs = ['turma_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span
                                                                                    class="text-danger"><?php echo e($message); ?></span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </select>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Foto Meio
                                                                            Corpo*</label>
                                                                        <input type="file" maxlength="50"
                                                                            min="5" name="img"
                                                                            value="storage/<?php echo e($item->img); ?>"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            placeholder="Nome Completo">
                                                                        <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Documentação
                                                                            Completa*</label>
                                                                        <input type="file" maxlength="50"
                                                                            min="5" name="doc"
                                                                            value="storage/<?php echo e($item->doc); ?>"
                                                                            class="form-control" id="exampleInputEmail1"
                                                                            placeholder="Nome Completo">
                                                                        <?php $__errorArgs = ['doc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span
                                                                                class="text-danger"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">Fechar</button>
                                                            <button type="submit" class="btn btn-success">Editar</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-danger">Nenhum aluno foi cadastrado!</span>
                                        <?php endif; ?>

                                    </tbody>
                                    
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tema.tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\canongue\resources\views/painel/alunos.blade.php ENDPATH**/ ?>