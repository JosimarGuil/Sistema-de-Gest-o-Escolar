

<?php $__env->startSection('title', 'adicionar alunos'); ?>
<?php $__env->startSection('content'); ?>
    <h1>ADICIONAR ALUNOS</h1>
    <a href="/list">Listar alunos</a>
    <hr>
    <ul>
    <form action="/adicionar" method="post">
    <?php echo csrf_field(); ?>
    <label for="">nome</label><br>
    <input type="text" name="nome"><br><br>
    <label for="">Contacto</label><br>
    <input type="tel" name="contacto"><br><br>
    <label for="">Curso</label><br>
    <input type="text" name="curso"><br><br>
    <label for="">Idade</label><br>
    <input type="number" name="idade"><br><br>
 <button type="submit">Enviar</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste\resources\views/alunos/add.blade.php ENDPATH**/ ?>