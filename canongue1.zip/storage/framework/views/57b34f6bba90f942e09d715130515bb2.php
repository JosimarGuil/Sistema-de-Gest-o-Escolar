

<?php $__env->startSection('title', 'Configurações da Escola Canongue'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>
                            Configurações gerais

                        </h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Painel</a></li>
                            <li class="breadcrumb-item active">Configurações da Escola</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Mensagens de retorno -->
        <section class="content-header">
            <div class="container-fluid">
                <?php if(session('sms1')): ?>
                    <div class="" style=" margin-bottom: 5px;">
                        <div class="card">
                            <div class="bg-primary" style="width:100%; margin: auto;padding: 10px; ">
                                <span><?php echo e(session('sms1')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms2')): ?>
                    <div class=" " style=" margin-bottom: 5px; ">
                        <div class="card">
                            <div class="bg-danger" style="width:100%; margin: auto;padding: 10px; ">
                                <span><?php echo e(session('sms2')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('sms3')): ?>
                    <div class=" " style=" margin-bottom: 5px; border-radius: 5px ">
                        <div class="card">
                            <div class="bg-success" style="width:100%; margin: auto;padding: 10px; ">
                                <span><?php echo e(session('sms3')); ?></span>
                                <div class="card-tools" style="float: right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <?php if(session('warning')): ?>
                    <div class="" style=" margin-bottom: 5px;">
                        <div class="bg-warning" style="width:100%; margin: auto;padding: 10px;">
                            <span><?php echo e(session('warning')); ?></span>
                            <div class="card-tools" style="float: right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">

                <div class="card card-warning card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-edit"></i>
                            Painel de Configuração
                        </h3>
                    </div>
                    <div class="card-body  justify-content-around">
                        <?php if(count($siculos) < 2): ?>
                            <button type="button" class="btn btn-success toastrDefaultSuccess " data-toggle="modal"
                                data-target="#modal-defaultciclus1">
                                Adicionar Cíclo
                            </button>
                        <?php endif; ?>
                        <button type="button" class="btn btn-info  toastrDefaultInfo" data-toggle="modal"
                            data-target="#modal-defaultcursos2">
                            Adicionar cursos
                        </button>

                        <button type="button" class="btn btn-warning  toastrDefaultInfo" data-toggle="modal"
                            data-target="#modal-defaultclasses5">
                            Adicionar Classe
                        </button>

                        <button type="button" class="btn btn-primary  toastrDefaultWarning" data-toggle="modal"
                            data-target="#modal-defaultsalas4">
                            Adicionar salas
                        </button>

                        <button type="button" class="btn btn-danger  toastrDefaultError" data-toggle="modal"
                            data-target="#modal-defaultturmas3">
                            Adicionar Turmas
                        </button>

                        <div class="text-muted mt-3">
                            <span>Zona restrita aos administradores do Canongue</span>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <!-- /.col -->



            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Ajustar Configurações da escola</h3><br>
                        <hr>


                        <button id="bci" type="button" class="btn btn-default toastrDefaultError"
                            onclick=" siculos(this)" style="color: white;background-color:#007bff ">
                            Ver todos Cíclos
                        </button>


                        <button id="bcu" type="button" class="btn btn-default toastrDefaultError"
                            onclick=" cursos(this)">
                            Ver todos Cursos
                        </button>
                        <button id="bcla" type="button" class="btn btn-default toastrDefaultError"
                            onclick="classes(this)">
                            Ver todas Classes
                        </button>
                        <button id="bsala" type="button" class="btn btn-default toastrDefaultError"
                            onclick="salas(this)">
                            Ver todas Salas
                        </button>
                        <button id="bturmas" type="button" class="btn btn-default toastrDefaultError"
                            onclick="turmas(this) ">
                            Ver todos Turmas
                        </button>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <!--TABELA DOS SICULOS-->
                        <div id="siculo" style="display: block">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Código</th>
                                        <th>Cíclo</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>----</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $siculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e($siculo->nome); ?></td>
                                            <td>----</td>
                                            <th>----</th>
                                            <th>----</th>
                                            <td>
                                                
                                                <button class="btn btn-warning" data-toggle="modal"
                                                    data-target="#modal-defaulteditciclu1<?php echo e($siculo->id); ?>"
                                                    style="display: inline-block"><i class="fas fa-trash"
                                                        title="Mover para Lixeira"></i></button>
                                            </td>
                                        </tr>
                                        <div class="modal fade" id="modal-defaulteditciclu1<?php echo e($siculo->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p class="text-default">Tem certeza que deseja mover este cíclo
                                                            para a lixeira? </p>
                                                        <form action="<?php echo e(route('deleteSiculo', $siculo->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <div class="card-footer">
                                                                <button type="submit"
                                                                    class="btn btn-warning
                                                            text-white">Sim</button>
                                                        </form>
                                                        <button type="button"
                                                            class="btn btn-danger
                                                            text-white"
                                                            data-dismiss="modal">Não</button>
                                                    </div>
                                                </div>
                                                <div class="modal-footer justify-content-between">
                                                    <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                                </div>
                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                        </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-danger">Nenhum Cíclo foi encontrado!</p>
                        <?php endif; ?>
                        <tfoot>
                            <tr>
                                <th>Codigo</th>
                                <th>Cíclo</th>
                                <th>----</th>
                                <th>----</th>
                                <th>----</th>
                                <th>Ações</th>
                            </tr>
                        </tfoot>
                        </table>
                    </div>
                    <!--TABELA DAS TURMAS-->
                    <div id="turmas" style="display: none">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <td>Código</td>
                                    <th>Turmas</th>
                                    <th>Período</th>
                                    <th>Classe</th>
                                    <th>Sala</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $turmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($turma->id); ?></td>
                                        <td><?php echo e($turma->nome); ?></td>
                                        <td><?php echo e($turma->periodo); ?></td>
                                        <td>
                                            <?php echo e($turma->clace->curso_id > 0 ? $turma->clace->nome . '-' . $turma->clace->curso->nome : $turma->clace->nome); ?>

                                        </td>
                                        <td><?php echo e($turma->sala->sala); ?></td>
                                        <td>
                                            <button class="btn btn-success" data-toggle="modal"
                                                data-target="#modal-defaulteditturma<?php echo e($turma->id); ?>"><i
                                                    class="fas fa-edit"></i></button>
                                            <button class="btn btn-warning" data-toggle="modal"
                                                data-target="#modal-defaulteditturma1<?php echo e($turma->id); ?>"
                                                style="display: inline-block"><i class="fas fa-trash"
                                                    title="Mover para Lixeira"></i></button>
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="modal-defaulteditturma1<?php echo e($turma->id); ?>">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>


                                                </div>
                                                <div class="modal-body">
                                                    <p class="text-default">Tem certeza que deseja mover esta turma para a
                                                        lixeira? </p>
                                                    <form action="<?php echo e(route('deleteTurma', $turma->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <div class="card-footer">
                                                            <button type="submit"
                                                                class="btn btn-warning
                                                            text-white">Sim</button>
                                                    </form>
                                                    <button type="button"
                                                        class="btn btn-danger
                                                            text-white"
                                                        data-dismiss="modal">Não</button>
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                    </div>
                    <div class="modal fade" id="modal-defaulteditturma<?php echo e($turma->id); ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Editar Turma</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form id="quickForm" action="<?php echo e(route('updateTurma', $turma->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Turma</label>
                                                <input type="text" name="turma" required class="form-control"
                                                    id="exampleInputEmail1" placeholder="Turma" maxlength="30"
                                                    minlength="2" value="<?php echo e(old('turma', $turma->nome)); ?>">
                                                <?php $__errorArgs = ['turma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Período</label>
                                                <select name="periodo" id="" class="form-control" required>
                                                    <option value="">Selecionar Período</option>
                                                    <option value="Manhã"
                                                        <?php echo e($turma->periodo == 'Manhã' ? 'selected' : ''); ?>>
                                                        Manhã</option>
                                                    <option value="Tarde"
                                                        <?php echo e($turma->periodo == 'Tarde' ? 'selected' : ''); ?>>
                                                        Tarde</option>
                                                    <option value="Noite"
                                                        <?php echo e($turma->periodo == 'Noite' ? 'selected' : ''); ?>>
                                                        Noite</option>
                                                </select>
                                                <?php $__errorArgs = ['periodo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Classe</label>
                                                <select name="clace_id" id="" class="form-control" required>
                                                    <option value="">Selecionar Classe</option>
                                                    <?php $__empty_2 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                        <?php if(isset($siculo->curso_id) and $siculo->curso_id != ''): ?>
                                                            <option value="<?php echo e($siculo->id); ?>"
                                                                <?php echo e($turma->clace->nome == $siculo->nome ? 'selected' : ''); ?>>
                                                                <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?>

                                                            </option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($siculo->id); ?>"
                                                                <?php echo e($turma->clace->nome == $siculo->nome ? 'selected' : ''); ?>>
                                                                <?php echo e($siculo->nome . '-' . $siculo->siculo->nome); ?>

                                                            </option>
                                                        <?php endif; ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <?php endif; ?>
                                                </select>
                                                <?php $__errorArgs = ['clace_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Salas</label>
                                                <select name="sala_id" id="" class="form-control" required>
                                                    <option value="">Selecionar Salas</option>
                                                    <?php $__empty_2 = true; $__currentLoopData = $salas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                        <option value="<?php echo e($curso->id); ?>"
                                                            <?php echo e($turma->sala->sala == $curso->sala ? 'selected' : ''); ?>>
                                                            <?php echo e($curso->sala); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <?php endif; ?>
                                                </select>
                                                <?php $__errorArgs = ['sala_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <!-- /.card-body -->
                                        <div class="card-footer">
                                            <button type="submit" class="btn btn-success"><i
                                                    class="fas fa-edit"></i></button>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>

                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="text-danger">Nenhuma sala foi encontrado!</span>
                    <?php endif; ?>
                    <tfoot>
                        <tr>
                            <td>Id</td>
                            <th>Turmas</th>
                            <th>Período</th>
                            <th>Classe</th>
                            <th>Sala</th>

                            <th>Ações</th>
                        </tr>
                    </tfoot>
                    </table>
                </div>


                <!--TABELA DAS SALAS-->
                <div id="salas" style="display: none">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Salas</th>
                                <th>----</th>
                                <th>----</th>
                                <th>----</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $salas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td><?php echo e($sala->sala); ?></td>
                                    <td>----</td>
                                    <th>----</th>
                                    <th>----</th>
                                    <td>
                                        <button class="btn btn-success" data-toggle="modal"
                                            data-target="#modal-defaulteditsala<?php echo e($sala->id); ?>"><i
                                                class="fas fa-edit"></i></button>

                                        <button class="btn btn-warning" data-toggle="modal"
                                            data-target="#modal-defaulteditsala1<?php echo e($sala->id); ?>"
                                            style="display: inline-block" title="Mover para Lixeira"><i
                                                class="fas fa-trash"></i></button>

                                    </td>

                                </tr>

                                <div class="modal fade" id="modal-defaulteditsala1<?php echo e($sala->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>


                                            </div>
                                            <div class="modal-body">
                                                <p class="text-default">Tem certeza que deseja mover esta sala para a
                                                    lixeira? </p>
                                                <form action="<?php echo e(route('deleteSala', $sala->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <div class="card-footer">
                                                        <button type="submit"
                                                            class="btn btn-warning
                                                            text-white">Sim</button>
                                                </form>
                                                <button type="button"
                                                    class="btn btn-danger
                                                            text-white"
                                                    data-dismiss="modal">Não</button>
                                            </div>

                                        </div>
                                        <div class="modal-footer justify-content-between">
                                            <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                        </div>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                </div>
                <div class="modal fade" id="modal-defaulteditsala<?php echo e($sala->id); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Editar Sala</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form id="quickForm" action="<?php echo e(route('updateSala', $sala->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Sala</label>
                                            <input type="number" name="sala" required class="form-control"
                                                id="exampleInputEmail1" placeholder="Nome do Siculo" maxlength="30"
                                                minlength="5" value="<?php echo e(old('sala', $sala->sala)); ?>">
                                            <?php $__errorArgs = ['sala'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-success"><i
                                                class="fas fa-edit"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>

                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <span class="text-danger">Nenhuma sala foi encontrado!</span>
                <?php endif; ?>
                <tfoot>
                    <tr>
                        <th>Codigo</th>
                        <th>Cíclo</th>
                        <th>----</th>
                        <th>----</th>
                        <th>----</th>
                        <th>Ações</th>
                    </tr>
                </tfoot>
                </table>
            </div>


            <!--TABELA DOS CURSOS-->
            <div id="curso" style="display: none">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Curso</th>
                            <th>Sigla</th>
                            <th>----</th>
                            <th>----</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($curso->nome); ?></td>
                                <td><?php echo e($curso->sigla); ?></td>
                                <th>----</th>
                                <th>----</th>
                                <td>

                                    <button class="btn btn-success" data-toggle="modal"
                                        data-target="#modal-defaulteditcurso<?php echo e($curso->id); ?>"><i
                                            class="fas fa-edit"></i></button>

                                    <button class="btn btn-warning" data-toggle="modal"
                                        data-target="#modal-defaulteditcurso1<?php echo e($curso->id); ?>"
                                        style="display: inline-block" title="Mover para Lixeira"><i
                                            class="fas fa-trash"></i></button>

                                </td>

                                <div class="modal fade" id="modal-defaulteditcurso1<?php echo e($curso->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-default">Tem certeza que deseja mover este curso para
                                                    lixeira? </p>
                                                <form action="<?php echo e(route('deleteCurso', $curso->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                            </div>

                                            <div class="card-footer">
                                                <button type="submit"
                                                    class="btn btn-warning
                                                        text-white">Sim</button>
                                                </form>
                                                <button type="button"
                                                    class="btn btn-danger
                                                        text-white"
                                                    data-dismiss="modal">Não</button>
                                            </div>

                                            <div class="modal-footer justify-content-between">
                                                <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>

                                <div class="modal fade" id="modal-defaulteditcurso<?php echo e($curso->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Editar Curso</h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form id="quickForm" action="<?php echo e(route('updateCurso', $curso->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="card-body">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Curso</label>
                                                            <input type="text" name="curso" required
                                                                class="form-control" id="exampleInputEmail1"
                                                                placeholder="Nome do Curso" maxlength="30" minlength="5"
                                                                value="<?php echo e(old('curso', $curso->nome)); ?>">
                                                            <?php $__errorArgs = ['curso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Sígla</label>
                                                            <input type="text" name="sigla" required
                                                                class="form-control" id="exampleInputEmail1"
                                                                placeholder="Sígla do Siculo" maxlength="6"
                                                                minlength="2" value="<?php echo e(old('sigla', $curso->sigla)); ?>">
                                                            <?php $__errorArgs = ['sigla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <!-- /.card-body -->
                                                    <div class="card-footer">
                                                        <button type="submit" class="btn btn-success"><i
                                                                class="fas fa-edit"></i></button>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <button type="button" class="btn btn-default"
                                                    data-dismiss="modal">Fechar</button>

                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span class="text-danger">Nenhum Cíclo foi encontrado!</span>
                        <?php endif; ?>

                    <tfoot>
                        <tr>
                            <th>Codigo</th>
                            <th>Curso</th>
                            <th>----</th>
                            <th>----</th>
                            <th>----</th>
                            <th>Ações</th>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <!--TABELA DAS CLASSES-->
            <div id="classes" style="display: none">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th colspan="2">Associação da Classe</th>
                            <th>Código</th>
                            <th>Classe</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <?php if(isset($classe->siculo->nome) and $classe->siculo->nome == 'Ensino Primário'): ?>
                                    <th>Cíclo</th>
                                    <td>Ensino Primário</td>
                                <?php endif; ?>
                                <?php if(isset($classe->siculo->nome) and $classe->siculo->nome == 'Primeiro Cíclo'): ?>
                                    <th>Cíclo</th>
                                    <td>Primeiro Cíclo</td>
                                <?php endif; ?>
                                <?php if(isset($classe->curso->nome)): ?>
                                    <th>Curso</th>
                                    <td><?php echo e($classe->curso->nome); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($classe->id); ?></td>
                                <td><?php echo e($classe->nome); ?></td>
                                <td>
                                    <button class="btn btn-success" data-toggle="modal"
                                        data-target="#modal-defaulteditclasse2<?php echo e($classe->id); ?>"><i
                                            class="fas fa-edit"></i></button>
                                    <button class="btn btn-warning" data-toggle="modal"
                                        data-target="#modal-defaulteditclasse1<?php echo e($classe->id); ?>"
                                        style="display: inline-block" title="Mover para Lixeira"><i
                                            class="fas fa-trash"></i></button>
                                </td>
                                <div class="modal fade" id="modal-defaulteditclasse1<?php echo e($classe->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                            </div>
                                            <div class="modal-body">
                                                <p class="text-default">Tem certeza que deseja mover este cíclo para a
                                                    lixeira?</p>
                                                <form action="<?php echo e(route('deleteClasse', $classe->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <div class="card-footer">
                                                        <button type="submit"
                                                            class="btn btn-warning
                                                                text-white">Sim</button>
                                                </form>
                                                <button type="button"
                                                    class="btn btn-danger
                                                                text-white"
                                                    data-dismiss="modal">Não</button>
                                            </div>
                                        </div>
                                        <div class="modal-footer justify-content-between">
                                            <h4 class="modal-title text-warning"> <b>AVISO!</b> </h4>
                                        </div>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
            </div>


            <div class="modal fade" id="modal-defaulteditclasse2<?php echo e($classe->id); ?>">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Editar Classe</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form id="quickForm" action="<?php echo e(route('updateClasse', $classe->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Classe</label>
                                        <select name="classe" id="" required class="form-control">
                                            <option value="">Selecione Uma Classe
                                            </option>
                                            <option value="">Ensino de Base</option>
                                            <option value="0" <?php echo e($classe->nome == 'Iniciação' ? 'selected' : ''); ?>>
                                                Iniciação</option>
                                            <option value="1" <?php echo e($classe->nome == '1-classe' ? 'selected' : ''); ?>>
                                                1-classe</option>
                                            <option value="2" <?php echo e($classe->nome == '2-classe' ? 'selected' : ''); ?>>
                                                2-classe</option>
                                            <option value="3" <?php echo e($classe->nome == '3-classe' ? 'selected' : ''); ?>>
                                                3-classe</option>
                                            <option value="4" <?php echo e($classe->nome == '4-classe' ? 'selected' : ''); ?>>
                                                4-classe</option>
                                            <option value="5" <?php echo e($classe->nome == '5-classe' ? 'selected' : ''); ?>>
                                                5-classe</option>
                                            <option value="6" <?php echo e($classe->nome == '6-classe' ? 'selected' : ''); ?>>
                                                6-classe</option>
                                            <option value="">Ensino Primário</option>
                                            <option value="7" <?php echo e($classe->nome == '7-classe' ? 'selected' : ''); ?>>
                                                7-classe</option>
                                            <option value="8" <?php echo e($classe->nome == '8-classe' ? 'selected' : ''); ?>>
                                                8-classe</option>
                                            <option value="9" <?php echo e($classe->nome == '9-classe' ? 'selected' : ''); ?>>
                                                9-classe</option>
                                            <option value="">Ensino Secundário
                                            </option>
                                            <option value="10" <?php echo e($classe->nome == '10-classe' ? 'selected' : ''); ?>>
                                                10-classe</option>
                                            <option value="11" <?php echo e($classe->nome == '11-classe' ? 'selected' : ''); ?>>
                                                11-classe</option>
                                            <option value="12" <?php echo e($classe->nome == '12-classe' ? 'selected' : ''); ?>>
                                                12-classe</option>
                                            <option value="13" <?php echo e($classe->nome == '13-classe' ? 'selected' : ''); ?>>
                                                13-classe</option>
                                        </select>
                                        <?php $__errorArgs = ['classe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Cíclo</label>
                                        <select name="siculo_id" id="" class="form-control">
                                            <option value="">Selecionar Cíclo
                                            </option>
                                            <?php $__empty_2 = true; $__currentLoopData = $siculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <option value="<?php echo e(old('siculo_id', $siculo->id)); ?>"
                                                    <?php echo e($siculo->id == $classe->siculo_id ? 'selected' : ''); ?>>
                                                    <?php echo e($siculo->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            <?php endif; ?>
                                        </select>
                                        <?php $__errorArgs = ['siculo_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Cursos</label>
                                        <select name="curso_id" id="" class="form-control">
                                            <option value="">Selecionar Curso
                                            </option>
                                            <?php $__empty_2 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <option value="<?php echo e(old('curso_id', $curso->id)); ?>"
                                                    <?php echo e($curso->id == $classe->curso_id ? 'selected' : ''); ?>>
                                                    <?php echo e($curso->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            <?php endif; ?>
                                        </select>
                                        <?php $__errorArgs = ['curso_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-success"><i class="fas fa-edit"></i></button>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>

                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span class="text-danger">Nenhuma Clase foi encontrado!</span>
            <?php endif; ?>

            <tfoot>
                <tr>
                    <th colspan="2">Associação da Classe</th>
                    <th>Codigo</th>
                    <th>Curso</th>
                    <th>Ações</th>
                </tr>
            </tfoot>
            </table>
    </div>
    </div>
    <!-- /.card-body -->
    </div>

    </div>

    <!--MODAL DOS SICULOS-->

    <div class="modal fade" id="modal-defaultciclus1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Cíclo</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="quickForm" action="<?php echo e(route('addSiculo')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Cíclo</label>
                                <select name="ciclu" class="form-control" id="nome" required>
                                    <option value="">Selecione um Cíclo</option>
                                    <option value="Ensino Primário">Ensino Primário</option>
                                    <option value="Primeiro Cíclo">Primeiro Cíclo</option>
                                </select>

                                <?php $__errorArgs = ['ciclu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Adicionar</button>
                        </div>

                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>


    <!--MODAL DAS CLASS-->

    <div class="modal fade" id="modal-defaultclasses5">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Classes</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="quickForm" action="<?php echo e(route('addClasse')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Classe</label>
                                <select name="classe" id="" required class="form-control">
                                    <option value="">Selecione Uma Classe</option>
                                    <option value="">Ensino de Primário</option>
                                    <option value="0">Iniciação</option>
                                    <option value="1">1-classe</option>
                                    <option value="2">2-classe</option>
                                    <option value="3">3-classe</option>
                                    <option value="4">4-classe</option>
                                    <option value="5">5-classe</option>
                                    <option value="6">6-classe</option>
                                    <option value="">Primeiro Cíclo</option>
                                    <option value="7">7-classe</option>
                                    <option value="8">8-classe</option>
                                    <option value="9">9-classe</option>
                                    <option value="">Ensino Secundário</option>
                                    <option value="10">10-classe</option>
                                    <option value="11">11-classe</option>
                                    <option value="12">12-classe</option>
                                    <option value="13">13-classe</option>
                                </select>
                                <?php $__errorArgs = ['classe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Cíclo</label>
                                <select name="siculo_id" id="" class="form-control">
                                    <option value="">Selecionar Cíclo</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $siculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($siculo->id); ?>"><?php echo e($siculo->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['siculo_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Cursos</label>
                                <select name="curso_id" id="" class="form-control">
                                    <option value="">Selecionar Curso</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['curso_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Adicionar</button>
                        </div>

                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>

                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>



    <!--MODAL DOS CURSOS-->

    <div class="modal fade" id="modal-defaultcursos2">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Cursos</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="quickForm" action="<?php echo e(route('addCurso')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Curso</label>
                                <input type="text" name="curso" required class="form-control"
                                    id="exampleInputEmail1" placeholder="Nome do Curso" maxlength="50" minlength="5"
                                    value="<?php echo e(old('curso')); ?>">
                                <?php $__errorArgs = ['curso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Sígla</label>
                                <input type="text" name="sigla" required class="form-control"
                                    id="exampleInputEmail1" placeholder="Sígla do Siculo" maxlength="6" minlength="2"
                                    value="<?php echo e(old('sigla')); ?>">
                                <?php $__errorArgs = ['sigla'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Adicionar</button>
                        </div>

                </div>
                <div class="modal-footer justify-content-between">

                    <button type="button" class="btn btn-default" data-dismiss="modal"
                        style="float: right">Fechar</button>

                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <!--MODAL DAS TURMAS-->

    <div class="modal fade" id="modal-defaultturmas3">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Turmas</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="quickForm" action="<?php echo e(route('addTurma')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Turma</label>
                                <input type="text" name="turma" required class="form-control"
                                    id="exampleInputEmail1" placeholder="Turma" maxlength="30" minlength="2"
                                    value="<?php echo e(old('turma')); ?>">
                                <?php $__errorArgs = ['turma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Período</label>
                                <select name="periodo" id="" class="form-control" required>
                                    <option value="">Selecionar Período</option>
                                    <option value="Manhã">Manhã</option>
                                    <option value="Tarde">Tarde</option>
                                    <option value="Noite">Noite</option>
                                </select>
                                <?php $__errorArgs = ['periodo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Classe</label>
                                <select name="clace_id" id="" class="form-control" required>
                                    <option value="">Selecionar Classes</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if(isset($siculo->curso_id)): ?>
                                            <option value="<?php echo e($siculo->id); ?>">
                                                <?php echo e($siculo->nome . '-' . $siculo->curso->nome); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($siculo->id); ?>">
                                                <?php echo e($siculo->nome); ?></option>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['clace_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Sala</label>
                                <select name="sala_id" id="" class="form-control" required>
                                    <option value="">Selecionar Salas</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $salas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->sala); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['sala_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Adicionar</button>
                        </div>

                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>

                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!--MODAL DAS SALAS-->

    <div class="modal fade" id="modal-defaultsalas4">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Adicionar Salas</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="quickForm" action="<?php echo e(route('addSala')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Sala</label>
                                <input type="number" name="sala" required class="form-control"
                                    id="exampleInputEmail1" placeholder="Sala" maxlength="30" minlength="5"
                                    value="<?php echo e(old('sala')); ?>">
                                <?php $__errorArgs = ['sala'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Adicionar</button>
                        </div>

                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>





    <!-- ./row -->
    </div><!-- /.container-fluid -->

    </section>
    <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tema.tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\canongue\resources\views/painel/configuracao.blade.php ENDPATH**/ ?>